from pathlib import Path
from time import sleep
from urllib.error import HTTPError
from urllib.request import urlopen
import json
from tank import online
from training.collect_boss_behavior import collect

open_impl=online.build_opener
maintenance=True
class Capture:
    def __init__(self,*args):
        self.opener=open_impl(*args)
    def open(self,req,**kwargs):
        global maintenance
        try:
            return self.opener.open(req,**kwargs)
        except HTTPError as e:
            if e.code==503 and req.selector.endswith('/start'):
                message=json.loads(e.read())['detail']
                maintenance=message=='新对局将在版本切换后开放'
                print('start',e.code,message,flush=True)
            raise
online.build_opener=Capture
for batch in ('dev','roaming','test'):
    waiting=False
    while True:
        health=json.load(urlopen(online.SITE+'/readyz',timeout=12))
        if not health['runtime'] and not health['idle']:
            raise SystemExit('官网运行状态异常')
        if maintenance and not health['runtime']:
            if not waiting:
                waiting=True
                print('waiting for practice rooms',flush=True)
            sleep(30)
            continue
        maintenance=False
        try:
            collect(Path.cwd(),batch)
            break
        except online.RequestUncertain:
            if not maintenance:
                raise
            sleep(30)
