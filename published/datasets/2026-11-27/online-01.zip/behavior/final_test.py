from pathlib import Path
from argparse import ArgumentParser
from training.boss_behavior_matches import matched_games
from training.evaluate_boss_behavior import trajectory_report,summarize_trajectory
from tank.workspace import read_json,write_json

parser=ArgumentParser()
parser.add_argument('model')
parser.add_argument('mode',choices=['trajectories','games'])
a=parser.parse_args()
root=Path.cwd()
out=root/'.local/behavior'
v1='v-bd574ebaa672affd93587a8c98e0acd015f8cdfb589587743c55a755fd32def1'
models=[v1,a.model]
rows=read_json(out/'batch-test.json')
if a.mode=='trajectories':
    historical=read_json(out/'final-historical.json')
    assert historical['ids']==[r['id'] for r in read_json(out/'batch-blind.json')]
    assert list(historical['models'])==models and historical['require_unseen'] and historical['stride_frames']==10 and historical['history_frames']==20
    ids=[r['id'] for r in rows]
    fresh=trajectory_report(root,models,ids,10,20,require_unseen=True,calibrate=True)
    def combine(left,right):
        data=left['replays']+right['replays']
        totals=summarize_trajectory([s for r in data for s in r['samples']],
                                    [s for r in data for s in r['threat_events']])
        return totals|{'replays':data}
    report=fresh | {'ids':historical['ids']+ids,'models':{m:combine(historical['models'][m],fresh['models'][m]) for m in models},
                    'replay_action_calibration':combine(historical['replay_action_calibration'], fresh['replay_action_calibration'])}
    write_json(out/'final-trajectories.json',report)
else:
    games=[]
    for seed in sorted({r['seed'] for r in rows}):
        keys=sorted({r['version_id'] for r in rows if r['seed']==seed})
        ids=[r['id'] for r in rows if r['seed']==seed]
        batch=matched_games(root,models,keys,[seed],out/'final-local-replays',
                            replay_ids=ids,require_unseen=True)
        games.extend(batch['games'])
    assert {(g['model'],g['replay_id']) for g in games}=={(m,r['id']) for m in models for r in rows}
    write_json(out/'final-games.json',{'models':models,'games':games})
