"""Package the fixed experiment for offline reproduction from a clean clone."""
import gzip
import hashlib
import json
import zipfile
from pathlib import Path
from tank import versions
from tank.workspace import read_json, write_json

root=Path.cwd()
local=root/'.local'
behavior=local/'behavior'
splits={name:read_json(behavior/f'batch-{name}.json') for name in (
    'oldA','oldB','fire','distance','roaming','dev','blind','test')}
selected=read_json(behavior/'selected.json')['model']
choices=read_json(behavior/'selected.json')['candidates']
last=next(m for m in choices if len(read_json(versions.snapshot_data(root,m)/'training.json')['train'])==58)
meta=read_json(versions.snapshot_data(root,last)/'training.json')
phases={k:[r['id'] for r in v] for k,v in splits.items()}
additional=set().union(*(set(phases[k]) for k in ('oldA','oldB','fire','distance','roaming')))
base=[r['id'] for r in meta['train'] if r['id'] not in additional]
dev=[14187,14200]+phases['dev']
test=phases['blind']+phases['test']
ids=sorted(set(base)|additional|set(dev)|set(test))
assert len(base)==27 and len(ids)==77 and len(dev)==6 and len(test)==13
target=root/'published/datasets'; target.mkdir(parents=True,exist_ok=True)
stem='boss-behavior-20261125'
digests={}
old='v-bd574ebaa672affd93587a8c98e0acd015f8cdfb589587743c55a755fd32def1'
snapshots={old,*choices}
for batch in ('fire','distance','roaming','dev','test'):
    snapshots.update(r['version_id'] for r in splits[batch])
opening=read_json(behavior/'boss-v1-closed-loop.json')
snapshots.update(opening['candidates'])
with zipfile.ZipFile(target/(stem+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    def put(name, data):
        info=zipfile.ZipInfo(name,date_time=(2026,11,25,0,0,0))
        archive.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    for key in sorted(snapshots):
        versions.verify(root,key)
        vp=versions.snapshot_data(root,key).parent
        fields=read_json(vp/'version.json')['files']
        for f in sorted(fields):
            assert f in {'bot.py','submission.json','training.json','weights.npz','navigation.py'}
            put(f'versions/{key}/files/{f}',(vp/'files'/f).read_bytes())
        put(f'versions/{key}/version.json',(vp/'version.json').read_bytes())
    for mid in ids:
        f=local/'online/replays'/f'{mid}.json.gz'
        raw=f.read_bytes()
        replay=json.loads(gzip.decompress(raw))
        assert replay['match']['public'] and replay['match']['id']==mid and replay['match']['kind']=='room'
        digests[mid]=hashlib.sha256(raw).hexdigest()
        put(f'online/replays/{f.name}',raw)
        for record in sorted((local/'online/practice').glob(f'*/boss/{mid}.json')):
            key=record.parents[1].name
            if key in snapshots:
                clean={k:v for k,v in read_json(record).items() if k in (
                    'id','version_id','map_seed','seed','side','team_id','level','result','opponent','score',
                    'room','replay_url')}
                put(record.relative_to(local).as_posix(), (json.dumps(clean,ensure_ascii=False)+'\n').encode())
    for name in splits:
        path=behavior/f'batch-{name}.json'
        put(f'behavior/{path.name}',path.read_bytes())
manifest={'rules':'2.6-prelim','initial_train':base,'added_train':{k:phases[k] for k in (
    'oldA','oldB','fire','distance','roaming')},'development':dev,'blind':test,'public_replay_sha256':digests,
    'selected_before_export':selected,'initial_model':old,'exported_model':read_json(behavior/'freeze.json')['model'],
    'development_candidates':choices,'blind_results':read_json(behavior/'final-compact.json'),
    'matched_blind_games':[{'id':g['replay_id'],'model':g['model'],'seed':g['seed'],'side':g['challenger_side'],
                            'official_seconds':round(g['official']['seconds'],1),'local_seconds':round(g['local']['seconds'],1)}
                           for g in read_json(behavior/'final-games.json')['games']],
    'archive_sha256':hashlib.sha256((target/(stem+'.zip')).read_bytes()).hexdigest()}
write_json(target/(stem+'.json'),manifest)
with zipfile.ZipFile(target/(stem+'.zip')) as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(f'online/replays/{i}.json.gz')).hexdigest()==h for i,h in digests.items())
print(len(ids),len(snapshots),(target/(stem+'.zip')).stat().st_size)
