from pathlib import Path
from statistics import median
from math import cos, sin, radians
from seedcup.game.replay import load
from seedcup.game import rules
from tank.workspace import read_json, write_json

root = Path.cwd()
base = root / '.local/behavior'
report = read_json(base / 'boss-v1-closed-loop.json')
results = []
for game in report['games']:
    if game['candidate'] == report['candidates'][0]:
        continue
    own = 1 if game['challenger_side'] == 'red' else 2
    tick_limit = round(game['same_duration']['official']['seconds'] / rules.DT)
    name = f"{game['replay_id']}.json.gz"
    for kind, filename in [('official', root / '.local/online/replays' / name),
                           ('local', base / 'replays' / game['model'] / name)]:
        frames = load(filename)['frames'][:tick_limit + 1]
        # Measure both sides of the same shot, projected across the shooter's recorded heading.
        shots = []
        for tick in range(5, len(frames) - 5):
            f = frames[tick]
            if f[own][10] == frames[tick - 1][own][10]:
                continue
            heading = radians(f[own][2])
            def cross_speed(t0, t1):
                start, end = frames[t0][3-own], frames[t1][3-own]
                dx, dy = end[0]-start[0], end[1]-start[1]
                return abs(-sin(heading)*dx + cos(heading)*dy) / ((t1-t0)*rules.DT)
            shots.append([tick, cross_speed(tick-5,tick), cross_speed(tick,tick+5)])
        results.append({'id': game['replay_id'], 'source': kind, 'shots': len(shots),
                        'before': median(e[1] for e in shots) if shots else None,
                        'after': median(e[2] for e in shots) if shots else None})
write_json(base / 'opening-shot-motion.json', results)
for kind in ('official','local'):
    use = [r for r in results if r['source']==kind and r['shots']]
    print(kind, len(use), sum(r['shots'] for r in use),
          {k:round(median(r[k] for r in use),3) for k in ('before','after')})
