import argparse
from collections import defaultdict
from pathlib import Path
from tank.workspace import read_json, write_json
from training.evaluate_boss_behavior import summarize_trajectory

def compact(summary):
    t = summary['threats']
    return {
        'positions': {h: round(v['position_error_cells']['mean'], 3)
                      for h, v in summary['trajectory'].items() if v['position_error_cells']['n']},
        'one_second_headings': round(summary['trajectory']['1.0']['heading_error_deg']['mean'], 2),
        'events': t['events_with_paired_hit_outcome'], 'reference_hits': t['reference_hits'],
        'predicted_hits': t['predicted_hits'], 'failed_evades': t['reference_evaded_but_predicted_hit'],
        'extra_evades': t['reference_hit_but_predicted_evaded'],
        'transverse_error': t['perpendicular_error_cells']['mean'],
        'n_half': summary['trajectory']['0.5']['position_error_cells']['n'],
    }

def by_group(records, field):
    groups = defaultdict(list)
    for r in records:
        groups[str(r[field])].append(r)
    result = {}
    for key, group in groups.items():
        combined = summarize_trajectory([s for r in group for s in r['samples']],
                                        [s for r in group for s in r['threat_events']])
        result[key] = compact(combined)
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    data = read_json(args.source)
    reports = data['models'].copy()
    if 'replay_action_calibration' in data:
        reports['calibration'] = data['replay_action_calibration']
    all_probes = {}
    for p in Path('.local/behavior').glob('batch-*.json'):
        for row in read_json(p):
            all_probes[row['id']] = row.get('probe','archive')
    out = {}
    for model, summary in reports.items():
        r = [g | {'probe':all_probes.get(g['id'],'archive')} for g in summary['replays']]
        out[model] = {'all':compact(summary), 'maps':by_group(r,'seed'), 'styles':by_group(r,'probe')}
    write_json(args.output, out)

if __name__ == '__main__':
    main()
