from argparse import ArgumentParser
from pathlib import Path
from statistics import fmean
from training.evaluate_boss_behavior import summarize_trajectory, trajectory_report
from tank.workspace import read_json, write_json

parser = ArgumentParser()
parser.add_argument('models', nargs='+')
args = parser.parse_args()
root = Path.cwd()
out = root / '.local/behavior'
ids = [14187,14200] + [r['id'] for r in read_json(out / 'batch-dev.json')]
raw = trajectory_report(root, args.models, ids, 10, 20, calibrate=True)
write_json(out / 'dev-selection.json', raw)
results = {}
for model, data in raw['models'].items():
    maps = {}
    for seed in (96671,715121):
        group = [r for r in data['replays'] if r['seed']==seed]
        summary = summarize_trajectory([s for r in group for s in r['samples']],
                                      [s for r in group for s in r['threat_events']])
        t = summary['threats']
        maps[str(seed)] = {'events': t['events_with_paired_hit_outcome'],
                           'actual_hits':t['reference_hits'], 'predicted_hits':t['predicted_hits'],
                           'failed_evades':t['reference_evaded_but_predicted_hit'],
                           'extra_evades':t['reference_hit_but_predicted_evaded'],
                           'accuracy':t['hit_outcome_accuracy'],
                           'position':summary['trajectory']['0.5']['position_error_cells']['mean']}
    results[model] = {'maps':maps, 'accuracy':fmean(m['accuracy'] for m in maps.values()),
                      'position':fmean(m['position'] for m in maps.values())}
best = min(results, key=lambda m:(-results[m]['accuracy'],results[m]['position']))
write_json(out / 'selected.json', {'model':best, 'candidates':results})
for k,v in results.items():
    print(k, round(v['accuracy'],4),round(v['position'],3))
print('selected',best)
