from gen import s,d,save
a=s.index('            # Back away');b=s.index('        diff = delta(target',a)
for gap in (6,9,13):
 for keep in (0,1):
  for window in (0.2,0.4):
   block=f'''            # Maintain a firing lane and enough space to sidestep a projectile.
            best = None
            for offset in (-65, 65, -35, 35, 0):
                direction = radians(bearing + offset)
                quality = 0
                for step in (2,4,6):
                    px = x - step*.25*cos(direction)
                    py = y - step*.25*sin(direction)
                    if not self.free(px,py):
                        quality -= 2
                        break
                    quality += 1
                    if clear_shot(self.walls,px,py,ex,ey):
                        quality += {keep}
                quality -= abs(delta(bearing+offset,heading))/150
                if best is None or quality > best[0]:
                    best = quality,offset
            if dist < {gap}:
                target, speed = bearing+best[1], -1
            else:
                target, speed = bearing, 0
'''
   save(f'gap{gap}k{keep}w{int(window*10)}',(s[:a]+block+s[b:]).replace('cooldown <= 0.35',f'cooldown <= {window}'))
