from gen import d,save
s=(d/'arc6p36d10.py').read_text()
for dist in (4,7,13):
 for near in (3,6,9):
  t=s.replace('or dist > 10:',f'or dist > {dist}:')
  a=t.index('            # Back away')
  b=t.index('        diff = delta(target',a)
  t=t[:a]+'''            if dist < NEAR:
                # Search for an exit around the nearest corner when boxed in.
                cell=(int(x),int(y))
                queue=deque([(cell,None,0)])
                visited={cell}
                best=None
                while queue:
                    pos,first,depth=queue.popleft()
                    if first:
                        px,py=pos[0]+.5,pos[1]+.5
                        quality=hypot(px-ex,py-ey)-depth*.35
                        if not clear_shot(self.walls,px,py,ex,ey):quality+=1.4
                        if best is None or quality>best[0]:best=quality,first
                    if depth<4:
                        for q in self.links[pos]:
                            if q not in visited:
                                visited.add(q)
                                queue.append((q,first or q,depth+1))
                wx,wy=best[1]
                target,speed=angle(wx+.5-x,wy+.5-y),1
            else:
'''.replace('NEAR',str(near))+''.join('    '+line for line in t[a:b].splitlines(keepends=True))+t[b:]
  save(f'exit{dist}n{near}',t)
