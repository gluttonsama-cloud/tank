from gen import d,save
s=(d/'threat5t3.py').read_text()
for radius in (3,6,10):
 t=(d/f'nav{radius}p0.py').read_text()
 a=t.index('    def firing_lane');b=t.index('    def dodge',a)
 u=s[:s.index('    def firing_lane')]+t[a:b]+s[s.index('    def dodge'):]
 u=u.replace('        self.previous = ex, ey','        self.foe_motion=vx,vy\n        self.previous = ex, ey')
 for scale in (.20,.36):
  z=u.replace('            for offset in (0.36,-0.36):',f'            for offset in ({scale},-{scale}):')
  save(f'peek{radius}s{int(scale*100)}',z)
