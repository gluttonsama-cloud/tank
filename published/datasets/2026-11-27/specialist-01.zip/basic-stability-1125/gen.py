from pathlib import Path
d=Path(__file__).resolve().parent;s=(d/'prev.py').read_text(encoding='utf8')
def save(n,t):(d/(n+'.py')).write_text(t,encoding='utf8')
for radius in (.22,.36):
 for safe in (6,10,99):
    t=s.replace('        zone = obs','''        center_visible = visible
        if not visible and dist > 1:
            nx, ny = -(ey-y)/dist, (ex-x)/dist
            for offset in (RADIUS,-RADIUS):
                px, py = ax+offset*nx, ay+offset*ny
                if clear_shot(self.walls,x,y,px,py):
                    ax, ay = px, py
                    bearing = angle(ax-x, ay-y)
                    visible = True
                    break
        zone = obs'''.replace('RADIUS',str(radius))).replace('elif cooldown <= 0.35:',f'elif cooldown <= 0.35 or not center_visible or dist > {safe}:')
    save(f'p{int(radius*100)}d{safe}',t)
