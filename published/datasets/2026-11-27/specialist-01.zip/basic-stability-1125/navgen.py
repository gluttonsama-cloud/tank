from gen import d,save
s=(d/'ray28a20.py').read_text()
a=s.index('    def firing_lane');b=s.index('    def dodge',a)
for radius in (3,6,10):
 for horizon in (0,5,12):
  block=f'''    def firing_lane(self,x,y,ex,ey):
        start=int(x),int(y)
        vx,vy=self.foe_motion
        gx,gy=ex,ey
        for i in range({horizon}):
            if not self.free(gx+vx,gy+vy):break
            gx+=vx
            gy+=vy
        queue=deque([(start,())])
        visited={{start}}
        while queue:
            cell,path=queue.popleft()
            if path and clear_shot(self.walls,cell[0]+.5,cell[1]+.5,gx,gy):
                for point in reversed(path[:3]):
                    dx,dy=point[0]+.5-x,point[1]+.5-y
                    steps=max(1,ceil(hypot(dx,dy)*4))
                    if all(self.free(x+dx*i/steps,y+dy*i/steps) for i in range(1,steps+1)):
                        return point[0]+.5,point[1]+.5
                return path[0][0]+.5,path[0][1]+.5
            if len(path)<{radius}:
                for q in self.links[cell]:
                    if q not in visited:
                        visited.add(q)
                        queue.append((q,path+(q,)))
        return self.waypoint(x,y,ex,ey)

'''
  save(f'nav{radius}p{horizon}',(s[:a]+block+s[b:]).replace('        self.previous = ex, ey','        self.foe_motion=vx,vy\n        self.previous = ex, ey'))
