from gen import d,save
s=(d/'selected.py').read_text()
for pace in (.3,.65,1):
 for gap in (6,10):
  block=f'''        elif not center_visible and dist>{gap} and cooldown>.15:
            # Move to a full firing lane between shots when only an edge is visible.
            wx,wy=self.firing_lane(x,y,ex,ey)
            target=angle(wx-x,wy-y)
            speed=min({pace},hypot(wx-x,wy-y)*4)
'''
  t=s.replace('        elif cooldown <= 0.35:',block+'        elif cooldown <= 0.35:') if '        elif cooldown <= 0.35:' in s else s.replace('        elif cooldown <= 0.35 or',block+'        elif cooldown <= 0.35 or')
  save(f'edge{int(pace*100)}g{gap}',t)
