from gen import d,save
s=(d/'peek6s36.py').read_text()
for horizon in (4,9,16):
 for slow in (.25,.8):
  block=f'''        if dist>1 and obs["frame"]<400:
            # The basic opponent normally halts once it sees us. Project motion
            # only until that first line of sight, limiting uncertain turns.
            px,py,eh=ex,ey,enemy["heading"]
            moving=hypot(vx,vy)
            for i in range(min({horizon},max(1,ceil((dist-.92)/1.2)))):
                if clear_shot(self.walls,px,py,x,y):
                    break
                error=delta(angle(x-px,y-py),eh)
                eh+=clamp(error/30,1)*18
                step=.25*(1 if abs(error)<60 else .2)
                if moving<.08 and i<2:step*={slow}
                dx,dy=step*cos(radians(eh)),step*sin(radians(eh))
                if not self.free(px+dx,py+dy):break
                px+=dx
                py+=dy
            ax,ay=px,py
'''
  t=s.replace('        if not self.free(ax, ay):',block+'        if not self.free(ax, ay):')
  save(f'stop{horizon}v{int(slow*100)}',t)
