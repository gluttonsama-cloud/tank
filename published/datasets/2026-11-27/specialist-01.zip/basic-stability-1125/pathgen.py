from gen import d,s,save
for depth in (6,12,20):
 for lead in (0,4):
  for baseline in ('prev','p36d10'):
   t=(d/(baseline+'.py')).read_text()
   block=f'''    def firing_lane(self, x, y, ex, ey):
        start = int(x), int(y)
        goal = (start,int(ex*2),int(ey*2))
        if getattr(self,"lane_key",None)==goal:
            return self.lane_step
        self.lane_key=goal
        vx,vy=self.enemy_velocity
        aimx,aimy=ex+vx*{lead},ey+vy*{lead}
        if not self.free(aimx,aimy):
            aimx,aimy=ex,ey
        queue=deque([(start,None,0)])
        visited={{start}}
        best=None
        while queue:
            cell,first,depth=queue.popleft()
            if best and depth>best[0]+1:
                break
            px,py=cell[0]+.5,cell[1]+.5
            if first and clear_shot(self.walls,px,py,aimx,aimy):
                quality=depth+max(0,10-hypot(px-aimx,py-aimy))*.65
                if best is None or quality<best[0]:
                    best=quality,first
            if depth < {depth}:
                for neighbor in self.links[cell]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append((neighbor,first or neighbor,depth+1))
        if best:
            first=best[1]
            self.lane_step=(first[0]+.5,first[1]+.5)
        else:
            self.lane_step=self.waypoint(x,y,ex,ey)
        return self.lane_step

'''
   a=t.index('    def firing_lane');b=t.index('    def decide',a)
   save(f'path{depth}l{lead}{baseline}',(t[:a]+block+t[b:]).replace('        self.previous = ex, ey','        self.enemy_velocity = vx, vy\n        self.previous = ex, ey'))
