from gen import d,save
block='''    def dodge(self,x,y,h,preferred,speed,shells,bearing,ready,visible):
        # Predict exact swept segments, truncated where they meet the map.
        paths=[]
        horizon=HORIZON
        for sx,sy,dx,dy in shells:
            end=ray_wall(self.walls,sx,sy,dx,dy,horizon*1.2)
            for i in range(horizon):
                length=min(1.2,end-i*1.2)
                if length<=0: break
                if len(paths)<=i:paths.append([])
                paths[i].append((sx+i*1.2*dx,sy+i*1.2*dy,dx,dy,length))
        if not paths:return preferred,speed
        best=None
        for turn in (preferred,-1,-.5,0,.5,1):
            for forward in (speed,1,-1,0):
                px,py,heading=x,y,h
                danger=0
                for i,segments in enumerate(paths):
                    if i < 3:heading+=turn*18
                    nx=px+forward*.25*cos(radians(heading))
                    ny=py+forward*.25*sin(radians(heading))
                    if self.free(nx,ny):px,py=nx,ny
                    elif self.free(nx,py):px=nx
                    elif self.free(px,ny):py=ny
                    for sx,sy,dx,dy,length in segments:
                        t=max(0,min(length,(px-sx)*dx+(py-sy)*dy))
                        distance=hypot(px-sx-t*dx,py-sy-t*dy)
                        danger=max(danger,max(0,.64-distance)*(1-.022*i))
                utility=-120*danger-abs(turn-preferred)*.28-abs(forward-speed)*.12
                if visible and ready and abs(delta(bearing,h+turn*18))<1:
                    utility+=.4
                if best is None or utility>best[0]:best=utility,turn,forward
        return best[1:]

'''
for base in ('prev','p36d10','path6l0p36d10'):
 for horizon in (6,10):
  t=(d/(base+'.py')).read_text().replace('import clear_shot, wall_grid','import clear_shot, wall_grid, ray_wall')
  t=t.replace('    def decide(',block.replace('HORIZON',str(horizon))+'    def decide(')
  t=t.replace('along < 10','along < '+str(horizon*1.2+1)).replace(' < 1.1:', ' < 1.4:').replace('self.evade(x,y,heading,turn,speed,incoming,safe_center,obs["frame"])','self.dodge(x,y,heading,turn,speed,incoming,bearing,cooldown<=.1,visible) if not self.retreating else self.evade(x,y,heading,turn,speed,incoming,safe_center,obs["frame"])')
  save('arc'+str(horizon)+base,t)
