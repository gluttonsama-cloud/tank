from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from statistics import mean
from importlib import import_module
import json,sys,random
from tank.simulation import run_match
from seedcup.game.bots import BaselineBot
D=Path(__file__).resolve().parent
def run(t):
    name,seed,side,rep=t
    class Bot(import_module(name).Lancer):
        first=None
        def decide(self,o):
            if self.first is None and o['self']['reload']>0:self.first=(o['frame']-1)/10
            return super().decide(o)
    b=Bot(); bots=[b,BaselineBot()]
    if side:bots.reverse()
    m=run_match(*bots,seed,rep);r=m['result'];s=r['scores'][side];a=r['stats'][side]
    return [name,seed,side,rep,s['total'],s['survive'],r['ticks']/10,a['shots'],a['hits'],b.first,int(m['winner']==side)]
def summary(g):
    scores=sorted(r[4] for r in g); n=len(g); low=sorted(g,key=lambda r:r[4])[:n//10]
    return [round(mean(scores),2), scores[n//10],round(mean(r[4] for r in low),2),round(mean(r[5] for r in low),2), round(mean(r[9] or 0 for r in low),2),round(mean(r[6] for r in g),2),sum(r[4]>=270 for r in g),sum(r[-1] for r in g),min(scores)]
if __name__=='__main__':
    group,n,*names=sys.argv[1:];lo={'fit':25000000,'dev':26000000,'final':27000000,'extra':28000000,'confirm':29000000}[group]
    seeds=random.Random(lo).sample(range(lo,lo+1000000),int(n))
    tasks=[(m,s,i,0) for m in names for s in seeds for i in (0,1)]
    with ProcessPoolExecutor(8) as pool: rows=list(pool.map(run,tasks,chunksize=5))
    for name in names:
        g=[r for r in rows if r[0]==name];(D/(group+'-'+name+'.json')).write_text(json.dumps(g));print(name,summary(g),flush=True)

