"""Grid navigation and short-horizon action selection for the SeedCup arcade arena."""
from collections import deque
from math import ceil, atan2, cos, degrees, hypot, radians, sin

from seedcup import Bot
from seedcup.game import rules
from seedcup.game.bots import clear_shot, wall_grid, ray_wall


ZONE_LOOKAHEAD = 30

# Fraction of constant-velocity displacement fitted on local SDK games.
LEAD = {(0, 1, 6, 1): 0.59575, (0, 1, 5, 1): 0.55401, (0, 1, 4, 1): 0.58425, (0, 1, 3, 1): 0.61948, (0, 1, 2, 1): 0.62282, (0, 1, 2, 0): 0.15697, (0, 1, 1, 0): 0.25184, (0, 1, 1, 1): 0.63609, (1, 1, 1, 1): 0.25173, (1, 1, 3, 1): 0.31744, (0, 1, 3, 0): 0.08562, (1, 1, 2, 0): 0.17055, (1, 1, 2, 1): 0.30222, (1, 1, 1, 0): 0.19554, (0, 1, 6, 0): 0.08039, (0, 1, 4, 0): 0.04972, (1, 1, 0, 0): 0.22536, (1, 1, 0, 1): 0.15322, (0, 1, 0, 0): 0.3881, (0, 1, 5, 0): 0.05518, (0, 1, 0, 1): 0.53504, (1, 1, 4, 1): 0.32033, (1, 1, 4, 0): 0.13671, (1, 1, 3, 0): 0.14509, (1, 1, 6, 1): 0.23964, (1, 1, 5, 1): 0.29895, (1, 1, 5, 0): 0.07563, (1, 1, 6, 0): 0.08933}


def angle(dx, dy):
    return degrees(atan2(dy, dx))


def delta(target, current):
    return (target - current + 180) % 360 - 180


def clamp(value, limit):
    return max(-limit, min(limit, value))


class Lancer(Bot):
    def on_match_start(self, info):
        self.grid = info["map"]["grid"]
        self.walls = wall_grid(info)
        self.open = {(x, y) for y, row in enumerate(self.grid)
                     for x, wall in enumerate(row) if not wall}
        self.links = {p: [q for q in ((p[0]+1,p[1]), (p[0]-1,p[1]),
                                      (p[0],p[1]+1), (p[0],p[1]-1)) if q in self.open]
                      for p in self.open}
        self.previous = None
        self.route_goal = None
        self.distances = {}
        self.retreating = False

    def waypoint(self, x, y, tx, ty):
        goal = int(tx), int(ty)
        if goal not in self.open:
            goal = min(self.open, key=lambda p: (p[0]+0.5-tx)**2 + (p[1]+0.5-ty)**2)
        if goal != self.route_goal:
            queue = deque([goal])
            dist = {goal: 0}
            while queue:
                p = queue.popleft()
                for q in self.links[p]:
                    if q not in dist:
                        dist[q] = dist[p] + 1
                        queue.append(q)
            self.distances, self.route_goal = dist, goal
        p = int(x), int(y)
        if p == goal:
            return goal[0]+0.5, goal[1]+0.5
        q = min(self.links[p], key=self.distances.__getitem__)
        # In a one-cell corridor, line up with its centre before turning a corner.
        return q[0]+0.5, q[1]+0.5

    def free(self, x, y):
        for cx in (int(x-.38), int(x+.38)):
            for cy in (int(y-.38), int(y+.38)):
                if (cx, cy) not in self.open:
                    dx = max(cx-x, 0, x-cx-1)
                    dy = max(cy-y, 0, y-cy-1)
                    if dx*dx + dy*dy < .38**2:
                        return False
        return True

    def evade(self, x, y, heading, preferred, speed, shells, safe_center, frame):
        # Rank short movement arcs by clearance from the visible game projectiles.
        best = None
        cx, cy = safe_center
        radii = [rules.zone_radius(frame + tick) for tick in range(1, 9)]
        already_outside = hypot(x-cx, y-cy) > radii[0]
        future_radius = rules.zone_radius(frame + ZONE_LOOKAHEAD)
        for turn in (-1, -.5, 0, .5, 1, preferred):
            for forward in (-1, 1, 0):
                px, py, h = x, y, heading
                clearance = 3
                zone_cost = 0
                for tick, radius in enumerate(radii, 1):
                    h += turn*18
                    nx = px + forward*.25*cos(radians(h))
                    ny = py + forward*.25*sin(radians(h))
                    if self.free(nx, ny):
                        px, py = nx, ny
                    if hypot(px-cx, py-cy) > radius:
                        # Prefer an in-zone next step if one is possible.
                        zone_cost += 26 if tick == 1 and not already_outside else .8
                    for sx, sy, vx, vy in shells:
                        along = clamp((px-sx)*vx + (py-sy)*vy - (tick-.5)*1.2, .6)
                        t = (tick-.5)*1.2 + along
                        clearance = min(clearance, hypot(px-sx-vx*t, py-sy-vy*t))
                utility = (min(clearance, .95)*20 - abs(turn-preferred)*.24
                           - abs(forward-speed)*.2
                           - zone_cost - max(0, hypot(px-cx, py-cy)-future_radius)*2)
                if best is None or utility > best[0]:
                    best = utility, turn, forward
        return best[1:]


    def firing_lane(self,x,y,ex,ey):
        start=int(x),int(y)
        queue=deque([(start,())])
        visited={start}
        while queue:
            cell,path=queue.popleft()
            if path and clear_shot(self.walls,cell[0]+.5,cell[1]+.5,ex,ey):
                for point in reversed(path[:3]):
                    dx,dy=point[0]+.5-x,point[1]+.5-y
                    steps=max(1,ceil(hypot(dx,dy)*4))
                    if all(self.free(x+dx*i/steps,y+dy*i/steps) for i in range(1,steps+1)):
                        return point[0]+.5,point[1]+.5
                return path[0][0]+.5,path[0][1]+.5
            if len(path)<6:
                for q in self.links[cell]:
                    if q not in visited:
                        visited.add(q)
                        queue.append((q,path+(q,)))
        return self.waypoint(x,y,ex,ey)

    def dodge(self,x,y,h,preferred,speed,shells,bearing,ready,visible):
        # Predict exact swept segments, truncated where they meet the map.
        paths=[]
        horizon=6
        for sx,sy,dx,dy in shells:
            end=ray_wall(self.walls,sx,sy,dx,dy,horizon*1.2)
            for i in range(horizon):
                length=min(1.2,end-i*1.2)
                if length<=0: break
                if len(paths)<=i:paths.append([])
                paths[i].append((sx+i*1.2*dx,sy+i*1.2*dy,dx,dy,length))
        if not paths:return preferred,speed
        best=None
        for turn in (preferred,-1,-.5,0,.5,1):
            for forward in (speed,1,-1,0):
                px,py,heading=x,y,h
                danger=0
                for i,segments in enumerate(paths):
                    if i < 3:heading+=turn*18
                    nx=px+forward*.25*cos(radians(heading))
                    ny=py+forward*.25*sin(radians(heading))
                    if self.free(nx,ny):px,py=nx,ny
                    elif self.free(nx,py):px=nx
                    elif self.free(px,ny):py=ny
                    for sx,sy,dx,dy,length in segments:
                        t=max(0,min(length,(px-sx)*dx+(py-sy)*dy))
                        distance=hypot(px-sx-t*dx,py-sy-t*dy)
                        danger=max(danger,max(0,.64-distance)*(1-.022*i))
                utility=-120*danger-abs(turn-preferred)*.28-abs(forward-speed)*.12
                if visible and ready and abs(delta(bearing,h+turn*18))<1:
                    utility+=.4
                if best is None or utility>best[0]:best=utility,turn,forward
        return best[1:]

    def decide(self, obs):
        me, enemy = obs["self"], obs["enemy"]
        x, y, heading = me["x"], me["y"], me["heading"]
        ex, ey = enemy["x"], enemy["y"]
        vx, vy = (0, 0) if self.previous is None else (ex-self.previous[0], ey-self.previous[1])
        self.previous = ex, ey
        dist = hypot(ex-x, ey-y)
        flight = max(1, min(24, ceil((dist-.92)/1.2)))
        if hypot(vx, vy) > .08:
            key = (int(clear_shot(self.walls, x, y, ex, ey)), 1, min(6, flight//3),
                   int(self.free(ex+vx*3, ey+vy*3)))
            flight *= LEAD.get(key, 1)
        ax, ay = ex+vx*flight, ey+vy*flight
        if not self.free(ax, ay):
            ax, ay = ex, ey
        bearing = angle(ax-x, ay-y)
        visible = clear_shot(self.walls, x, y, ax, ay)
        center_visible = visible
        if not visible and dist > 1:
            nx, ny = -(ey-y)/dist, (ex-x)/dist
            for offset in (0.36,-0.36):
                px, py = ax+offset*nx, ay+offset*ny
                if clear_shot(self.walls,x,y,px,py):
                    ax, ay = px, py
                    bearing = angle(ax-x, ay-y)
                    visible = True
                    break
        zone = obs["zone"]
        safe_center = zone["x"], zone["y"]
        safe_radius = rules.zone_radius(obs["frame"] + ZONE_LOOKAHEAD)
        margin = 1.1 if self.retreating else .6
        self.retreating = hypot(x-safe_center[0], y-safe_center[1]) > safe_radius-margin
        cooldown = me["reload"]
        if self.retreating or not visible:
            tx, ty = safe_center if self.retreating else (ex, ey)
            wx, wy = self.waypoint(x,y,tx,ty) if self.retreating else self.firing_lane(x,y,ex,ey)
            target = angle(wx-x, wy-y)
            speed = min(1, hypot(wx-x,wy-y)*4)
        elif not center_visible and dist>10 and cooldown>.15:
            # Move to a full firing lane between shots when only an edge is visible.
            wx,wy=self.firing_lane(x,y,ex,ey)
            target=angle(wx-x,wy-y)
            speed=min(0.65,hypot(wx-x,wy-y)*4)
        elif cooldown <= 0.35 or not center_visible or dist > 7:
            target, speed = bearing, 0
        else:
            # Search for an exit around the nearest corner when boxed in.
            cell=(int(x),int(y))
            queue=deque([(cell,None,0)])
            visited={cell}
            best=None
            while queue:
                pos,first,depth=queue.popleft()
                if first:
                    px,py=pos[0]+.5,pos[1]+.5
                    quality=hypot(px-ex,py-ey)-depth*.35
                    if not clear_shot(self.walls,px,py,ex,ey):quality+=1.4
                    if best is None or quality>best[0]:best=quality,first
                if depth<4:
                    for q in self.links[pos]:
                        if q not in visited:
                            visited.add(q)
                            queue.append((q,first or q,depth+1))
            wx,wy=best[1]
            target,speed=angle(wx+.5-x,wy+.5-y),1
        diff = delta(target, heading)
        if speed and abs(diff) > 90:
            diff = delta(target+180, heading)
            speed = -speed
        turn = clamp(diff/18, 1)
        if abs(diff) > 55:
            speed *= .35
        incoming = []
        frame = obs["frame"]
        if any(not sh["mine"] and hypot(sh["x"]-ex,sh["y"]-ey)<1.73 for sh in obs["shells"]):
            self.last_enemy_shot = frame-1
        until = max(0, 15 - (frame-getattr(self,"last_enemy_shot",-100)))
        if dist < 5 and until <= 3 and visible:
            enemy_angle=radians(enemy["heading"])
            dx,dy=cos(enemy_angle),sin(enemy_angle)
            if abs(delta(angle(x-ex,y-ey),enemy["heading"])) < 12:
                # A projected round reaches the muzzle after the opponent reloads.
                offset=.5-until*1.2
                incoming.append((ex+offset*dx,ey+offset*dy,dx,dy))

        for s in obs["shells"]:
            if s["mine"]:
                continue
            dx, dy = x-s["x"], y-s["y"]
            along = dx*s["dx"]+dy*s["dy"]
            if 0 < along < 8.2 and abs(dx*s["dy"]-dy*s["dx"]) < 1.4:
                incoming.append((s["x"],s["y"],s["dx"],s["dy"]))
        if incoming:
            turn, speed = self.dodge(x,y,heading,turn,speed,incoming,bearing,cooldown<=.1,visible) if not self.retreating else self.evade(x,y,heading,turn,speed,incoming,safe_center,obs["frame"])
        fire = visible and abs(delta(bearing,heading+turn*18))*max(dist,1) < 24
        return {"forward": speed, "turn": turn, "fire": fire}
