from gen import d,save
s=(d/'threat5t3.py').read_text()
a=s.index('        if not visible and dist > 1:')
b=s.index('        zone = obs',a)
for margin in (.28,.37):
 for tol in (12,20,28):
  block=f'''        if not visible and dist>1:
            # Aim through the first clear line that reaches the hit circle.
            length=hypot(ax-x,ay-y)
            nx,ny=-(ay-y)/length,(ax-x)/length
            for offset in (.14,-.14,{margin},-{margin}):
                px,py=ax+offset*nx,ay+offset*ny
                raylen=hypot(px-x,py-y)
                dx,dy=(px-x)/raylen,(py-y)/raylen
                lateral=(ax-x)*dy-(ay-y)*dx
                enter=(ax-x)*dx+(ay-y)*dy-(.42**2-lateral**2)**.5
                travel=max(.2,ceil((enter-.5)/.2)*.2)
                if ray_wall(self.walls,x+.5*dx,y+.5*dy,dx,dy,travel)>=travel:
                    ax,ay=px,py
                    bearing=angle(dx,dy)
                    visible=True
                    break
'''
  t=s[:a]+block+s[b:]
  save(f'ray{int(margin*100)}a{tol}',t.replace('max(dist,1) < 24',f'max(dist,1) < {tol}'))
