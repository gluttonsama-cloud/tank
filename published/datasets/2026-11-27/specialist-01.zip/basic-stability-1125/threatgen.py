from gen import d,save
s=(d/'exit7n9.py').read_text()
for gap in (5,8,12):
 for lead in (1,3,5):
  t=s.replace('        incoming = []','''        incoming = []
        frame = obs["frame"]
        if any(not sh["mine"] and hypot(sh["x"]-ex,sh["y"]-ey)<1.73 for sh in obs["shells"]):
            self.last_enemy_shot = frame-1
        until = max(0, 15 - (frame-getattr(self,"last_enemy_shot",-100)))
        if dist < GAP and until <= LEAD and visible:
            enemy_angle=radians(enemy["heading"])
            dx,dy=cos(enemy_angle),sin(enemy_angle)
            if abs(delta(angle(x-ex,y-ey),enemy["heading"])) < 12:
                # A projected round reaches the muzzle after the opponent reloads.
                offset=.5-until*1.2
                incoming.append((ex+offset*dx,ey+offset*dy,dx,dy))
'''.replace('GAP',str(gap)).replace('LEAD',str(lead)))
  save(f'threat{gap}t{lead}',t)
