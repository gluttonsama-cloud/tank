from gen import d,save
s=(d/'peek6s36.py').read_text()
for ticks in (0,4,10):
 for factor in (0,.18,.55):
  t=s.replace('for i in range(0):',f'for i in range({ticks}):')
  t=t.replace('        if not visible and dist > 1:','''        frame=obs["frame"]
        if enemy["hp"] != getattr(self,"prior_hp",None) or center_visible:
            self.prior_hp=enemy["hp"]
            self.last_progress=frame
        if not visible and dist > 1 and frame-self.last_progress<32:''')
  t=t.replace('            flight *= LEAD.get(key, 1)',f'            flight *= {factor} if key[0] else LEAD.get(key,1)')
  save(f'track{ticks}f{int(factor*100)}',t)
