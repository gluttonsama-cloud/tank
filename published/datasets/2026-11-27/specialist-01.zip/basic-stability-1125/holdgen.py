from gen import d,save
s=(d/'threat5t3.py').read_text()
for gap in (3,5,8):
 for tilt in (0,40,70):
  t=s.replace('or dist > 7:',f'or dist > {gap}:')
  a=t.index('            if dist < 9:')
  b=t.index('        diff = delta(target',a)
  block=f'''            # Prepare a lateral escape while retaining the firing lane.
            turn_side=1 if delta(bearing,heading)>=0 else -1
            if getattr(self,"escape_sign",None) is None or cooldown>=1.4:
                self.escape_sign=turn_side
            target,speed=bearing+self.escape_sign*{tilt},0
'''
  t=t[:a]+block+t[b:]
  save(f'hold{gap}a{tilt}',t)
