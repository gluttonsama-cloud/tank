"""Resume the single local trajectory follow-up after the fixed sampling batch."""
import argparse
import hashlib
import json
import os
import runpy
import subprocess
import sys
import tempfile
import time
from collections import Counter, defaultdict
from pathlib import Path
from statistics import median

from prepare_trajectory_followup import BLIND_SEEDS, TRAIN_SEEDS, prepare
from seedcup.game import rules
from seedcup.game.replay import load
from start_trajectory import BASE

from tank import jobs, sampling, sampling_data, versions
from tank.eval_store import shard_lock, worker_lock
from tank.workspace import project_root, read_json, write_json

HERE = Path(__file__).resolve().parent
CONTROL = HERE / "trajectory-followup"
STATE = CONTROL / "status.json"
LOG = CONTROL / "worker.log"
BATCH = "sample-38205f75c62d46cea91124d9a344ca44"
ORIGINAL_JOB = "train-88dbc1b8e0144577b14876547203639e"
FIXED = "v-87e73b37a2442ed097ab0511e200130534fdcac0fd1d1e6c9f67ad32513e113e"
PROBES = {
    "specialist-v7": "v-0921b165f76c1e667e4b1ae1e22c35dd3ada329ae317800db44b1d71bcc6a174",
    "lancer-v7": "v-2b9dfa9a5fa442edd0b7b4c223228034fce69d5b4e94e416d8f763244dc7e825",
}
POLL_SECONDS = 30


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def update(previous, **details):
    value = dict(previous, **details)
    if value != previous or not STATE.exists():
        write_json(STATE, value | {"updated_at": time.time()})
    return value


def launch(arguments, folder, log, env):
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("ab") as stream:
        return subprocess.Popen([sys.executable, "-B", "-u", str(Path(__file__).resolve()), *arguments],
                                cwd=folder, stdin=subprocess.DEVNULL, stdout=stream, stderr=stream,
                                env=env | {"OPENBLAS_NUM_THREADS": "1", "PYTHONUTF8": "1",
                                           "PYTHONDONTWRITEBYTECODE": "1"},
                                creationflags=flags, start_new_session=os.name != "nt")


def verify_batch(root, rows):
    plan = sampling.record(root, BATCH)["plan"]
    if plan["maps"] != 4 or plan["repeats"] != 2 or plan["versions"] != PROBES:
        raise ValueError("采样批次计划与冻结的四图、两版本、两遍计划不符")
    expected = Counter((seed, version, side, repeat) for seed in TRAIN_SEEDS | BLIND_SEEDS
                       for version in PROBES.values() for side in ("red", "blue") for repeat in (1, 2))
    observed = Counter((row["seed"], row["version_id"], row["target_side"], row["repeat"]) for row in rows)
    if observed != expected:
        raise ValueError(f"采样槽位不齐，缺 {expected - observed}，多 {observed - expected}")
    for row in rows:
        if row["target"] != "boss" or PROBES.get(row["probe"]) != row["version_id"]:
            raise ValueError(f"回放 {row['id']} 的探针对不上冻结的版本")


def official_variation(root, rows):
    cases = defaultdict(list)
    for row in rows:
        key = (row["seed"], row["grid_sha256"], row["version_id"], row["target_side"], row["game_no"])
        cases[key].append(row)
    if len(cases) != 16 or any({row["repeat"] for row in repeats} != {1, 2} for repeats in cases.values()):
        raise ValueError("32 局必须可按布局、策略、出生侧和官网局号配成 16 对")
    pairs = []
    for (seed, layout, probe, side, game_no), repeats in sorted(cases.items()):
        results = []
        for row in sorted(repeats, key=lambda item: item["repeat"]):
            path = root / row["path"]
            if digest(path) != row["sha256"]:
                raise ValueError(f"官网回放 {row['id']} 的哈希不符")
            replay = load(path)
            if replay["match"]["id"] != row["id"] or replay["match"]["game"] != game_no:
                raise ValueError(f"官网回放 {row['id']} 的局号不符")
            result = replay["result"]
            results.append({"id": row["id"], "seconds": result["ticks"] * rules.DT,
                            "winner_side": result["winner_side"]})
        before, after = results
        pairs.append({"seed": seed, "layout": layout, "probe_version": probe,
                      "boss_side": side, "game_no": game_no, "repeats": results,
                      "abs_duration_delta_s": abs(before["seconds"] - after["seconds"]),
                      "winner_disagrees": before["winner_side"] != after["winner_side"]})
    return {"pairs": len(pairs), "layouts": len({row["layout"] for row in pairs}),
            "median_abs_duration_delta_s": median(row["abs_duration_delta_s"] for row in pairs),
            "winner_disagreements": sum(row["winner_disagrees"] for row in pairs), "games": pairs}


def stage_job(root, manifest):
    original = jobs._job_dir(root, ORIGINAL_JOB)
    old = read_json(original / "request.json")
    if jobs.status(root, ORIGINAL_JOB)["snapshot_id"] != FIXED:
        raise ValueError("原 245 局训练作业的候选快照不符")
    manifest_sha = digest(manifest)
    identity = hashlib.sha256(f"{ORIGINAL_JOB}:{manifest_sha}".encode()).hexdigest()[:32]
    job_id = f"train-{identity}"
    target = jobs._job_dir(root, job_id)
    group = read_json(manifest)
    source_manifest = original / old["inputs"][0]["path"]
    if digest(source_manifest) != old["params"]["manifest_sha256"]:
        raise ValueError("原作业训练清单的归档哈希不符")
    original_groups = read_json(source_manifest)
    original_train = [(row["id"], row["sha256"]) for row in original_groups["train"]]
    observed_train = [(row["id"], row["sha256"]) for row in group["train"]]
    if len(group["train"]) != 261 or group["dev"] != original_groups["dev"] or observed_train[:245] != original_train:
        raise ValueError("扩展训练清单需要原 245 局、额外 16 局及原 36 局开发")
    params = old["params"] | {"manifest_sha256": manifest_sha}
    if target.exists():
        existing = read_json(target / "request.json")
        if existing["params"] != params or any(existing[key] != old[key] for key in ("sources", "workbench", "config")):
            raise ValueError(f"已有训练作业 {job_id} 与固定源码或清单不一致")
        return job_id
    with tempfile.TemporaryDirectory(dir=target.parent) as temp:
        stage = Path(temp) / "job"
        sources = jobs._freeze_python(original / "training", stage / "training")
        workbench = jobs._freeze_python(original / "workbench/tank", stage / "workbench/tank")
        if sources != old["sources"] or workbench != old["workbench"]:
            raise ValueError("原作业源码归档哈希不符")
        inputs = []
        paths = [(manifest, manifest_sha)] + [(root / row["path"], row["sha256"])
                                             for name in ("train", "dev") for row in group[name]]
        for index, (source, expected) in enumerate(paths):
            relative = Path("inputs") / f"{index:03d}" / source.name
            copied = jobs._freeze(source, stage / relative)
            if copied != expected:
                raise ValueError(f"冻结的输入内容与清单不符 {source}")
            inputs.append({"source": str(source), "path": relative.as_posix(), "sha256": copied})
        request = old | {"job_id": job_id, "params": params, "inputs": inputs, "source_job": ORIGINAL_JOB}
        write_json(stage / "request.json", request)
        write_json(stage / "queued.json", {"job_id": job_id, "status": "queued", "created_at": time.time()})
        stage.rename(target)
    return job_id


def fit(root, job_id):
    folder = jobs._job_dir(root, job_id)
    with worker_lock(folder, 0) as acquired:
        if not acquired or (folder / "finished.json").exists():
            return
        request_file = folder / "request.json"
        request = read_json(request_file)
        output = folder / request["output"]
        state = read_json(folder / "queued.json") | {"status": "running", "started_at": time.time(), "pid": os.getpid()}
        write_json(folder / "running.json", state)
        try:
            if not (output / "result.json").exists():
                if output.exists():
                    output.rename(folder / f"output-interrupted-{time.time_ns()}")
                output.mkdir()
                script = folder / "training" / request["script"]
                os.chdir(folder)
                sys.path.insert(0, str(script.parent))
                sys.argv = [str(script), str(request_file)]
                runpy.run_path(str(script), run_name="__main__")
            result = jobs._register_output(root, request, output)
        except Exception as error:
            write_json(folder / "finished.json", state | {"status": "failed", "error": str(error),
                                                         "finished_at": time.time()})
            raise
        write_json(folder / "finished.json", state | result | {"status": "completed", "finished_at": time.time()})


def fit_snapshot(root, job_id):
    folder = jobs._job_dir(root, job_id)
    finished = folder / "finished.json"
    if not finished.is_file():
        with shard_lock(folder, 0) as free:
            if free:
                env = jobs._command_environment(folder) | {"TANK_ROOT": str(root)}
                worker = launch(["fit", job_id], folder, folder / "worker.log", env)
                write_json(folder / "launch.json", {"pid": worker.pid})
        while not finished.is_file():
            status = jobs.status(root, job_id)
            if status["status"] == "interrupted":
                raise RuntimeError("扩展训练进程退出，可重新运行 start 续接同一训练作业")
            time.sleep(5)
    status = jobs.status(root, job_id)
    if status["status"] != "completed":
        raise RuntimeError(f"扩展训练失败 {status['error']}")
    return status["snapshot_id"]


def evaluate(root, model, manifest, report, *, timed=False):
    expected = (BASE, FIXED, model)
    script = "eval_timed_sensitivity.py" if timed else "eval_trajectory.py"
    split_args = [] if timed else ["--split", "blind"]
    if not report.exists():
        env = dict(os.environ, OPENBLAS_NUM_THREADS="1", PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1")
        subprocess.run([sys.executable, "-B", "-u", str(HERE / script),
                        "--manifest", str(manifest), *split_args, "--models", *expected,
                        "--workers", "2", "--output", str(report)],
                       cwd=root, check=True, env=env, stdin=subprocess.DEVNULL)
    result = read_json(report)
    if (result["report"]["manifest_sha256"] != digest(manifest)
            or set(result["aggregate"]) != set(expected) or result["report"]["split"] != "blind"):
        raise ValueError("已有独立验收报告的模型、分组或清单不符")
    return result


def primary_metrics(result):
    fields = ("median_range_error_cells", "seconds_error", "boss_death_disagreement")
    return {key: {metric: row[metric] for metric in fields} for key, row in result["aggregate"].items()}


def work(root):
    with worker_lock(CONTROL, 0) as acquired:
        if not acquired:
            return
        previous = read_json(STATE) if STATE.is_file() else {}
        if previous.get("state") == "completed":
            return
        state = {"pid": os.getpid(), "sampling_id": BATCH, "source_job": ORIGINAL_JOB, "base": BASE,
                 "fixed_snapshot": FIXED, "log": str(LOG)}
        print(f"Follow-up coordinator PID {os.getpid()}: {BATCH}", flush=True)
        try:
            while True:
                sample = sampling.status(root, BATCH)
                state = update(state, state="waiting_for_samples", sampling_state=sample["state"],
                               sampling_message=sample["message"], samples=sample["games"],
                               planned=sample["planned_games"])
                if sample["games"] == sample["planned_games"] == 32 and sample["state"] == "completed":
                    break
                time.sleep(POLL_SECONDS)
            batch_export = HERE / "trajectory-followup-batch.json"
            sampling_data.dataset(root, "boss", run=BATCH, output=batch_export)
            rows = read_json(batch_export)
            verify_batch(root, rows)
            prepare(HERE, batch_export)
            manifest = HERE / "manifest-trajectory-extended.json"
            job_id = stage_job(root, manifest)
            state = update(state, state="training", job_id=job_id, manifest_sha256=digest(manifest))
            model = fit_snapshot(root, job_id)
            versions.verify(root, model)
            variation = official_variation(root, rows)
            variation_path = HERE / "official-repeat-variation.json"
            write_json(variation_path, variation)
            state = update(state, state="evaluating", extended_snapshot=model)
            report = HERE / "eval-independent-trajectory.json"
            independent = HERE / "manifest-trajectory-independent.json"
            result = evaluate(root, model, independent, report)
            variation_summary = {key: variation[key] for key in ("pairs", "layouts", "median_abs_duration_delta_s",
                                                                "winner_disagreements")}
            state = update(state, state="evaluating_sensitivity", report=str(report),
                           replays=result["report"]["replays"], primary=primary_metrics(result),
                           official_repeat_report=str(variation_path), official_repeat_summary=variation_summary)
            timed_report = HERE / "eval-independent-trajectory-timed.json"
            timed = evaluate(root, model, independent, timed_report, timed=True)
            update(state, state="completed", timed_report=str(timed_report), timed_primary=primary_metrics(timed))
        except Exception as error:
            update(state, state="failed", error=str(error))
            raise


def status():
    return read_json(STATE) if STATE.is_file() else {"state": "not_started", "sampling_id": BATCH}


def start_worker(root):
    with shard_lock(CONTROL, 0) as free:
        current = status()
        if not free or current["state"] == "completed":
            return current
        if current["state"] == "starting" and jobs._process_exists(current["pid"]):
            return current
        env = jobs._command_environment(root) | {"TANK_ROOT": str(root), "PYTHONPATH": ""}
        child = launch(["work"], root, LOG, env)
        return update({}, state="starting", pid=child.pid, sampling_id=BATCH, log=str(LOG))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("start", "status", "work", "fit"))
    parser.add_argument("job", nargs="?")
    args = parser.parse_args()
    root = project_root()
    if args.mode == "fit":
        fit(root, args.job)
    elif args.mode == "work":
        work(root)
    else:
        print(json.dumps(start_worker(root) if args.mode == "start" else status(), ensure_ascii=False))


if __name__ == "__main__":
    main()
