from collections import defaultdict
from pathlib import Path
from statistics import fmean

from tank.workspace import read_json, write_json

ROUND = Path(__file__).resolve().parent
RULE = read_json(ROUND / "selection-rule.json")
MANIFEST = read_json(ROUND / "manifest.json")


def compare(report):
    base = report["models"]["baseline"]["closed_loop_metrics"]
    candidate = report["models"]["candidate"]["closed_loop_metrics"]
    by_id = {r["id"]: r for r in MANIFEST[report["split"]]}
    by_probe = defaultdict(lambda: defaultdict(list))
    for game in report["games"]:
        meta = by_id[game["id"]]
        pair = [game[k]["closed_loop"]["metrics"]["seconds_error"] for k in ("baseline", "candidate")]
        by_probe[meta["probe"] or meta["version_id"]][game["grid_sha256"]].append(pair[1] - pair[0])
    probe_delta = {k: fmean(fmean(values) for values in grids.values()) for k, grids in by_probe.items()}
    strong = {
        "range": candidate["median_range_error_cells"] < base["median_range_error_cells"],
        "duration": candidate["seconds_error"] <= base["seconds_error"],
        "death": candidate["boss_death_disagreement"] <= base["boss_death_disagreement"],
        "all_styles": max(probe_delta.values()) <= RULE["promotion_gate"]["max_probe_style_seconds_error_increase"],
    }
    return {
        "snapshot": report["run"]["model_ids"]["candidate"],
        "error_ratio": fmean(candidate[k] / base[k] for k in RULE["closed_loop_metrics"]),
        "close_error": report["models"]["candidate"]["frame_metrics"]["within_3_cells"]["displacement_error_cells"],
        "criteria": strong, "passes": all(strong.values()), "probe_duration_delta": probe_delta,
        "baseline": base, "candidate": candidate,
    }


if __name__ == "__main__":
    import sys
    if sys.argv[1] == "dev":
        rows = {k: compare(read_json(ROUND / f"eval-dev-{k}.json")) for k in RULE["dev_candidates"]}
        best = min(rows, key=lambda k: (not rows[k]["passes"], rows[k]["error_ratio"], rows[k]["close_error"]))
        write_json(ROUND / "locked.json", {"selected": best, "snapshot": rows[best]["snapshot"], "dev": rows})
        print(best, {k: (round(v["error_ratio"], 3), v["criteria"]) for k, v in rows.items()})
    else:
        locked = read_json(ROUND / "locked.json")
        verified = read_json(ROUND / sys.argv[1])
        assert verified["split"] == "blind" and verified["run"]["model_ids"]["candidate"] == locked["snapshot"]
        result = compare(verified)
        write_json(ROUND / "validation.json", result)
        print(result)
