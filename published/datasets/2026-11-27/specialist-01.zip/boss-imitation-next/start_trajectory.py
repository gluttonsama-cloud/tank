"""Launch the frozen local trajectory-imitation job from a replay manifest."""
import argparse
import hashlib
import json
from pathlib import Path

from tank.jobs import start
from tank.training import TrainingStore
from tank.workspace import project_root, read_json

BASE = "v-8eafb7605945a640bfaf4dd85d6920dc75df3fcd5fa42a32ada7d7dcbd41af26"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()
    root = project_root()
    manifest = read_json(args.manifest)
    paths = [root / row["path"] for group in ("train", "dev") for row in manifest[group]]
    config = TrainingStore(root).register_config(
        teacher_snapshot=BASE, opponent_pool={"baseline": 1}, sampling_seed=20261125,
    )
    params = {"policy": "trajectory-imitation", "manifest_sha256": hashlib.sha256(
        args.manifest.read_bytes()).hexdigest()}
    record = start(root, "fit_boss_sparring.py", config, [args.manifest, *paths], params)
    print(json.dumps(record, ensure_ascii=False))


if __name__ == "__main__":
    main()
