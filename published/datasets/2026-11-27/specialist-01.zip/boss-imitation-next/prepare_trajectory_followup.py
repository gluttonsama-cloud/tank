"""Freeze the two training and two blind layouts from the separate sample batch."""
import argparse
from collections import Counter
from pathlib import Path

from tank.workspace import read_json, write_json

TRAIN_SEEDS = {187754736, 187964194}
BLIND_SEEDS = {187650007, 187859465}


def prepare(folder, batch_export):
    baseline = read_json(folder / "manifest.json")
    batch = read_json(batch_export)
    sides = Counter((row["seed"], row["target_side"]) for row in batch)
    expected = Counter({(seed, side): 4 for seed in TRAIN_SEEDS | BLIND_SEEDS for side in ("red", "blue")})
    if len({row["id"] for row in batch}) != 32 or sides != expected:
        raise ValueError(f"本轮需要指定的四张图各红蓝4局，实际为 {sides}")
    for seed in TRAIN_SEEDS | BLIND_SEEDS:
        if len({row["grid_sha256"] for row in batch if row["seed"] == seed}) != 1:
            raise ValueError(f"地图 {seed} 的墙面布局不一致")
    if len({row["grid_sha256"] for row in batch}) != 4:
        raise ValueError("新增四张图的墙面布局必须各自独立")
    for key in ("id", "seed", "grid_sha256"):
        existing = {row[key] for group in ("train", "dev", "blind") for row in baseline[group]}
        if existing & {row[key] for row in batch}:
            raise ValueError(f"独立采集和原清单重叠 {key}")
    train = [row | {"split": "train"} for row in batch if row["seed"] in TRAIN_SEEDS]
    blind = [row | {"split": "blind"} for row in batch if row["seed"] in BLIND_SEEDS]
    extended = baseline | {"train": baseline["train"] + train}
    write_json(folder / "manifest-trajectory-extended.json", extended)
    write_json(folder / "manifest-trajectory-independent.json", extended | {"blind": blind})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("batch_export", type=Path)
    args = parser.parse_args()
    prepare(Path(__file__).parent, args.batch_export)


if __name__ == "__main__":
    main()
