"""Replay frozen probe matches in the SDK and measure event agreement."""
import argparse
import hashlib
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from math import hypot
from pathlib import Path

from eval_round import (
    ROOT,
    closed_game,
    common_alive_distances,
    find_model,
    local_factory,
    means,
    paired_game,
    read_json,
    read_manifest,
    read_trace,
    rules,
    summarize_match,
    versions,
    write_json,
)

EVENTS = ("approach_4_cells_s", "retreat_4_to_6_cells_s", "first_hit_received_s")


def event_times(replay, side):
    summary = summarize_match(replay, 1 - side)
    close_time = summary["first_within_4_cells_s"]
    retreat = None
    if close_time is not None:
        close_tick = round(close_time * rules.TICK_HZ)
        retreat = next(((tick - close_tick) * rules.DT
                        for tick, red, blue, _, _ in replay["frames"][close_tick + 1:]
                        if red[4] and blue[4] and hypot(red[0] - blue[0], red[1] - blue[1]) >= 6), None)
    return {"approach_4_cells_s": close_time, "retreat_4_to_6_cells_s": retreat,
            "first_hit_received_s": summary["boss"]["first_hit_received_s"]}


def run_layout(task):
    entries, models = task
    samples = [read_trace(entry) for entry in entries]
    matches = {}
    for model, folder in models.items():
        with local_factory(folder) as factory:
            matches[model] = [closed_game(replay, trace, factory, entry["version_id"])
                              for entry, (replay, trace) in zip(entries, samples, strict=True)]
    for index, (entry, (replay, trace)) in enumerate(zip(entries, samples, strict=True)):
        simulations = [matches[model][index] for model in models]
        paired = common_alive_distances(replay, simulations)
        ref = event_times(replay, trace.side)
        result = {}
        for model, simulation, distance in zip(models, simulations, paired, strict=True):
            local = event_times(simulation, trace.side)
            row = paired_game(replay, simulation, trace.side, distance)
            row["reference"].update(ref)
            row["predicted"].update(local)
            row["metrics"].update({
                f"{name}_mae": abs(value - local[name]) if value is not None and local[name] is not None else None
                for name, value in ref.items()
            })
            row["metrics"].update({
                f"{name}_presence_disagreement": float((value is None) != (local[name] is None))
                for name, value in ref.items()
            })
            result[model] = row
        yield {"replay_id": entry["id"], "layout": entry["grid_sha256"], "seed": entry["seed"],
               "probe": entry["probe"], "probe_version": entry["version_id"], "runs": result}


def report_layout(task):
    return list(run_layout(task))


def event_coverage(layouts, models):
    results = {}
    for event in EVENTS:
        key = f"{event}_mae"
        common = [[game for game in rows if all(game["runs"][model]["metrics"][key] is not None
                                                for model in models)] for rows in layouts]
        results[event] = {
            "jointly_observed_games": {
                model: sum(game["runs"][model]["metrics"][key] is not None for rows in layouts for game in rows)
                for model in models},
            "all_models_observed_games": sum(map(len, common)),
            "all_models_observed_layouts": sum(map(bool, common)),
            "all_models_observed_mae_s": {
                model: means(means({"mae": game["runs"][model]["metrics"][key]} for game in rows)
                             for rows in common if rows).get("mae")
                for model in models},
        }
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--split", default="dev", choices=("dev", "blind"))
    parser.add_argument("--models", nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=6)
    args = parser.parse_args()
    locations = dict(find_model(name)[::-1] for name in args.models)
    groups = defaultdict(list)
    entries = read_manifest(args.manifest)[args.split]
    if args.split == "blind":
        blind_seeds = {row["seed"] for row in entries}
        if blind_seeds != {187650007, 187859465} or len(entries) != 16:
            parser.error("盲测只接受本轮预先划定的16局独立验收")
        for model, folder in locations.items():
            provenance = read_json(folder / "training.json")
            for field in ("id", "seed"):
                frozen = {row[field] for group in ("train", "holdout") for row in provenance[group]}
                if frozen & {row[field] for row in entries}:
                    parser.error(f"{model} 已使用盲测数据 {field}")
    for probe in {entry["version_id"] for entry in entries}:
        if probe is None:
            parser.error("闭环整局对照的每场回放都需要冻结探针版本")
        versions.verify(ROOT, probe)
    for entry in entries:
        groups[entry["grid_sha256"]].append(entry)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        games = []
        for rows in pool.map(report_layout, [(rows, locations) for rows in groups.values()]):
            games.append(rows)
            print(f"{rows[0]['seed']}: {len(rows)} completed", flush=True)
    layouts = [{model: means(game["runs"][model]["metrics"] for game in rows) for model in locations}
               for rows in games]
    aggregated = {model: means(layout[model] for layout in layouts) for model in locations}
    write_json(args.output, {
        "report": {"manifest_sha256": hashlib.sha256(args.manifest.read_bytes()).hexdigest(), "split": args.split,
                   "replays": len(entries), "layouts": len(groups), "map_weighting": "equal",
                   "common_alive_median_range": True, "approach_threshold_cells": 4,
                   "retreat_threshold_cells": 6, "retreat_time_is_relative_to_approach": True,
                   "event_mae_conditions_on_observed_event_in_both_games": True},
        "aggregate": aggregated, "layouts": dict(zip(groups, layouts, strict=True)),
        "event_coverage": event_coverage(games, locations),
        "games": [game for rows in games for game in rows],
    })


if __name__ == "__main__":
    main()
