"""Compare frozen boss policies on the same official observations and paired SDK games."""

import argparse
import hashlib
import sys
from collections import Counter, defaultdict
from contextlib import contextmanager
from itertools import pairwise
from math import hypot
from pathlib import Path
from statistics import fmean

from seedcup.client.loader import load_bot
from seedcup.game import parse_action, rules
from seedcup.game.engine import SIDES, action_fields, ang_diff
from seedcup.game.replay import ReplayRecorder, load
from seedcup.game.runner import play

from tank import versions
from tank.sampling_data import layout_hash
from tank.workspace import project_root, read_json, write_json

ROOT = project_root()
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))

from training.boss_behavior_matches import (
    MOVEMENT_START_DISTANCE,
    common_alive_distances,
    compare_movement_starts,
    movement_start,
    rate,
    summarize_match,
)
from training.evaluate_boss_behavior import (
    THREAT_TICKS,
    ReplayTrace,
    branch,
    engine_action,
    static_intercept,
)

SPLITS = ("train", "dev", "blind")
GROUPS = ("all", "within_3_cells", "opening_3s", "incoming_threat")
OPENING_TICKS = 3 * rules.TICK_HZ
HISTORY_TICKS = 20
START_THRESHOLD = MOVEMENT_START_DISTANCE + 1e-12
BOSS_MODELS = ("baseline", "candidate")
# The next float32 after 1.0, observed after action retrieval averages weights.
ACTION_ROUNDING_LIMIT = 1.0 + 2 ** -23


def find_model(value):
    path = Path(value)
    if path.is_dir():
        folder = path if (path / "submission.json").is_file() else path / "files"
    else:
        versions.verify(ROOT, value)
        folder = versions.snapshot_data(ROOT, value)
    folder = folder.resolve()
    files = {
        name: digest for name, digest in versions._file_hashes(folder).items()
        if "__pycache__" not in Path(name).parts and not name.endswith(".pyc")
    }
    spec = read_json(folder / "submission.json")
    path, separator, _ = spec["entrypoint"].partition(":")
    if spec["runtime"] != "python" or not separator or path not in files:
        raise ValueError(f"逐帧评估需要有效的 Python SDK 类入口 {folder}")
    identity = versions._version_id(files)
    if folder.name == "files" and folder.parent.name.startswith("v-") and folder.parent.name != identity:
        raise ValueError(f"快照内容不符 {folder.parent.name}")
    return folder, identity


@contextmanager
def local_factory(folder):
    entry, name = read_json(folder / "submission.json")["entrypoint"].split(":", 1)
    entry = folder / entry
    siblings = {path.stem for path in entry.parent.glob("*.py")}
    siblings.update(path.name for path in entry.parent.iterdir() if (path / "__init__.py").is_file())

    def sibling_modules():
        return [key for key in sys.modules if key.partition(".")[0] in siblings]

    old_path = sys.path[:]
    previous = {key: sys.modules.pop(key) for key in sibling_modules()}
    try:
        yield load_bot(f"{entry}:{name}")
    finally:
        sys.path[:] = old_path
        for key in sibling_modules():
            del sys.modules[key]
        sys.modules.update(previous)


def read_manifest(path):
    manifest = read_json(path)
    ids = set()
    layouts, seeds = {}, {}
    for split in SPLITS:
        for entry in manifest[split]:
            replay_id, grid = entry["id"], entry["grid_sha256"]
            if replay_id in ids:
                raise ValueError(f"清单对局 ID 重复 {replay_id}")
            if layouts.setdefault(grid, split) != split or seeds.setdefault(entry["seed"], split) != split:
                raise ValueError(f"地图跨分组 {replay_id}")
            ids.add(replay_id)
    return manifest


def read_trace(entry):
    path = ROOT / entry["path"]
    if "sha256" in entry and hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
        raise ValueError(f"回放文件哈希不符 {path}")
    replay = load(path)
    trace = ReplayTrace(replay)
    if (trace.meta["id"] != entry["id"] or SIDES[trace.side] != entry["target_side"]
            or trace.game_map.seed != entry["seed"] or layout_hash(replay["map"]) != entry["grid_sha256"]):
        raise ValueError(f"回放 ID、地图或终极人机出生侧与清单不符 {path}")
    return replay, trace


def threat_frames(trace):
    return {
        tick for tick, shells in enumerate(trace.shells[:-1])
        if any(shell.owner != trace.side and static_intercept(
            trace.game_map, shell, *trace.frames[tick][trace.side + 1][:2]) is not None
            for shell in shells.values())
    }


def checked_action(raw, replay_id, tick, source):
    action, bad = parse_action(raw)
    if not bad:
        return action, False
    fields = action_fields(raw)
    if fields and None not in fields.values() and max(abs(raw[key]) for key in ("forward", "turn")) <= ACTION_ROUNDING_LIMIT:
        return action, True
    raise ValueError(f"回放 {replay_id} 第 {tick} 帧的{source}动作无效 {raw!r}")


class CheckedBot:
    def __init__(self, bot, trace, source, *, first_scored_tick=0, return_raw=False):
        self.bot = bot
        self.replay_id = trace.meta["id"]
        self.source = source
        self.first_scored_tick = first_scored_tick
        self.return_raw = return_raw
        self.boundary_clips = 0

    def on_match_start(self, info):
        self.bot.on_match_start(info)

    def decide(self, obs):
        tick = obs["frame"]
        raw = self.bot.decide(obs)
        action, clipped = checked_action(raw, self.replay_id, tick, self.source)
        self.boundary_clips += clipped and tick >= self.first_scored_tick
        return raw if self.return_raw else action

    def on_match_end(self, result):
        self.bot.on_match_end(result)


def frame_counts(trace, factory, danger_ticks):
    counts = {group: Counter() for group in GROUPS}
    side = trace.side
    bot = factory()
    bot.on_match_start(trace.info())
    for tick, (before, after) in enumerate(pairwise(trace.frames)):
        own, opponent = before[side + 1], before[2 - side]
        if not own[4]:
            raise ValueError(f"回放 {trace.meta['id']} 在第 {tick} 帧前终局")
        observed = after[side + 1]
        game = trace.state(tick)
        action, clipped = checked_action(bot.decide(game.observe(side)), trace.meta["id"], tick, "陪练")
        actions = [engine_action(item) for item in trace.actions[tick]]
        actions[side] = action
        game.step(actions)
        predicted = game.tanks[side]
        reference_speed = hypot(observed[0] - own[0], observed[1] - own[1])
        predicted_speed = hypot(predicted.x - own[0], predicted.y - own[1])
        row = Counter(
            frames=1,
            boundary_clips=int(clipped),
            displacement_error_cells=hypot(predicted.x - observed[0], predicted.y - observed[1]),
            speed_error_cells=abs(predicted_speed - reference_speed),
            turn_error_deg=abs(ang_diff(predicted.h, observed[2])),
        )
        # The SDK decrements reload before accepting fire, so a tick at 1 is eligible.
        if own[5] <= 1:
            fired = observed[10] > own[10]
            label = ("t" if fired == predicted.fired else "f") + ("p" if predicted.fired else "n")
            row[label] = 1
        counts["all"].update(row)
        groups = (hypot(own[0] - opponent[0], own[1] - opponent[1]) <= 3,
                  tick < OPENING_TICKS, tick in danger_ticks)
        for group, include in zip(GROUPS[1:], groups, strict=True):
            if include:
                counts[group].update(row)
    return counts


def frame_summary(c):
    tp, fp, fn, tn = (c[name] for name in ("tp", "fp", "fn", "tn"))
    return {
        **{key: rate(c[key], c["frames"]) for key in
           ("displacement_error_cells", "speed_error_cells", "turn_error_deg")},
        "fire_precision": rate(tp, tp + fp) if tp + fp else (0.0 if fn else None),
        "fire_recall": rate(tp, tp + fn),
        "fire_f1": rate(2 * tp, 2 * tp + fp + fn),
        "fire_false_positive_rate": rate(fp, fp + tn),
        "fire_predicted_rate": rate(tp + fp, tp + fp + fn + tn),
    }


def threat_counts(trace, factory, event_groups):
    result = Counter()
    for tick, events in event_groups.items():
        bot = CheckedBot(factory(), trace, "逐弹分支陪练", first_scored_tick=tick)
        _, predictions = branch(trace, lambda bot=bot: bot, tick, (THREAT_TICKS,), events, HISTORY_TICKS)
        result["boundary_clips"] += bot.boundary_clips
        for row in predictions:
            actual_hit = row["reference_hit"]
            predicted_hit = row["predicted_hit"]
            result["events"] += 1
            result["position_error_cells"] += row["half_second_position_error_cells"]
            result["lateral_error_cells"] += abs(row["reference_perpendicular_cells"] - row["predicted_perpendicular_cells"])
            if actual_hit is None:
                result["outcome_unresolved"] += 1
            else:
                result["ref_hit" if actual_hit else "ref_evaded"] += 1
                result["predicted_hits"] += predicted_hit
                result["correct_hit" if actual_hit else "correct_evade"] += actual_hit == predicted_hit
    return result


def threat_summary(c):
    return {
        "position_error_cells": rate(c["position_error_cells"], c["events"]),
        "lateral_error_cells": rate(c["lateral_error_cells"], c["events"]),
        "hit_outcome_accuracy": rate(c["correct_evade"] + c["correct_hit"], c["ref_evaded"] + c["ref_hit"]),
        "official_evade_reproduced_rate": rate(c["correct_evade"], c["ref_evaded"]),
        "official_hit_reproduced_rate": rate(c["correct_hit"], c["ref_hit"]),
    }


def opening(trace, factory):
    own = trace.side + 1
    end = min(trace.end, OPENING_TICKS)
    bot = CheckedBot(factory(), trace, "开局分支陪练")
    rows, _ = branch(trace, lambda: bot, 0, range(1, end + 1), (), 0)
    spawn = trace.game_map.spawns[trace.side]
    reference = movement_start(trace.frames[:end + 1], own, spawn)

    def distance(point):
        return hypot(point[0] - spawn.x, point[1] - spawn.y)

    start = next((tick * rules.DT for tick, row in rows.items()
                  if distance(row["prediction_xy"]) > START_THRESHOLD), None)
    displacement = distance(rows[end]["prediction_xy"]) if end == OPENING_TICKS else None
    predicted = {"seconds": start, "censor_lower_bound_s": end * rules.DT if start is None else None,
                 "displacement_at_3s_cells": displacement}
    difference = compare_movement_starts(reference, predicted)
    return {
        "boundary_clips": bot.boundary_clips,
        "metrics": {
            "movement_start_error_s": difference["abs_error_s"],
            "movement_start_error_lower_bound_s": difference["abs_error_lower_bound_s"],
            "movement_not_started_by_3s": float(start is None) if end == OPENING_TICKS else None,
            "displacement_at_3s_error_cells": abs(displacement - reference["displacement_at_3s_cells"])
            if displacement is not None else None,
            "position_at_3s_error_cells": rows[end]["position_error_cells"] if end == OPENING_TICKS else None,
            "heading_at_3s_error_deg": rows[end]["heading_error_deg"] if end == OPENING_TICKS else None,
        },
        "reference": reference,
        "predicted": predicted,
    }


def closed_game(replay, trace, factory, probe_id):
    bot = CheckedBot(factory(), trace, "闭环陪练", return_raw=True)
    probe = versions.load_bot(ROOT, probe_id)
    checked_probe = CheckedBot(probe, trace, "闭环探针", return_raw=True)
    bots = (bot, checked_probe) if trace.side == 0 else (checked_probe, bot)
    recorder = ReplayRecorder(trace.game_map, trace.meta)
    names = tuple(trace.meta[side]["name"] for side in SIDES)
    try:
        game = play(trace.game_map, bots, names, recorder=recorder, game_no=trace.meta["game"])
    finally:
        if hasattr(probe, "close"):
            probe.close()
    if game.violations != [item.boundary_clips for item in bots]:
        raise ValueError(f"回放 {trace.meta['id']} 的闭环对局有未归因的违规动作 {game.violations}")
    local = recorder.to_dict(game.result.to_dict())
    if local["frames"][0][:4] != replay["frames"][0][:4]:
        raise ValueError(f"回放 {trace.meta['id']} 的闭环初始状态与官网不一致")
    return local


def paired_game(replay, local, boss_side, paired_distance):
    probe_side = 1 - boss_side
    reference = summarize_match(replay, probe_side)
    simulated = summarize_match(local, probe_side)
    boss, official = simulated["boss"], reference["boss"]
    probe, official_probe = simulated["challenger"], reference["challenger"]
    common_ticks = paired_distance["frames"]

    def travel(data, side):
        states = [frame[side + 1] for frame in data["frames"][:common_ticks]]
        return sum(hypot(b[0] - a[0], b[1] - a[1]) for a, b in pairwise(states))

    close = {"seconds_error": abs(reference["seconds"] - simulated["seconds"]),
             "boss_hits_received_error": abs(official_probe["hits"] - probe["hits"]),
             "probe_hits_received_error": abs(official["hits"] - boss["hits"]),
             "boss_travel_error_cells": abs(travel(replay, boss_side) - travel(local, boss_side)),
             "probe_travel_error_cells": abs(travel(replay, probe_side) - travel(local, probe_side)),
             "median_range_error_cells": abs(paired_distance["official_median_distance_cells"] -
                                             paired_distance["local_median_distance_cells"]),
             "boss_death_disagreement": float(replay["frames"][-1][boss_side + 1][4] !=
                                              local["frames"][-1][boss_side + 1][4])}
    return {"metrics": close, "common_alive_frames": common_ticks,
            "boundary_clips": {"boss": local["frames"][-1][boss_side + 1][-1],
                               "probe": local["frames"][-1][probe_side + 1][-1]},
            "reference": {"seconds": reference["seconds"], "boss_hits": official["hits"],
                          "probe_hits": official_probe["hits"]},
            "predicted": {"seconds": simulated["seconds"], "boss_hits": boss["hits"], "probe_hits": probe["hits"]}}


def summed(rows):
    result = Counter()
    for row in rows:
        result.update(row)
    return result


def means(rows):
    values = defaultdict(list)
    for row in rows:
        for key, value in row.items():
            samples = values[key]
            if value is not None:
                samples.append(value)
    return {key: fmean(samples) if samples else None for key, samples in values.items()}


def map_report(rows, model):
    frames = {group: summed(row[model]["frame_counts"][group] for row in rows) for group in GROUPS}
    events = summed(row[model]["threat_counts"] for row in rows)
    frame_metrics = {group: frame_summary(c) for group, c in frames.items()}
    for group, c in frames.items():
        if not c["tp"] + c["fn"]:
            for key in ("fire_precision", "fire_recall", "fire_f1"):
                frame_metrics[group][key] = None
    return {"frame_metrics": frame_metrics, "frame_counts": frames,
            "threat_metrics": threat_summary(events), "threat_counts": events,
            "opening_metrics": means(row[model]["opening"]["metrics"] for row in rows),
            "boundary_clips": {
                "frame": frames["all"]["boundary_clips"],
                "threat_branch": events["boundary_clips"],
                "opening_branch": sum(row[model]["opening"]["boundary_clips"] for row in rows),
                **{f"closed_loop_{side}": sum(row[model]["closed_loop"]["boundary_clips"][side] for row in rows
                                              if "closed_loop" in row[model]) for side in ("boss", "probe")},
            },
            "closed_loop_metrics": means(row[model]["closed_loop"]["metrics"] for row in rows
                                         if "closed_loop" in row[model])}


def aggregate(games):
    layouts = defaultdict(list)
    for game in games:
        layouts[game["grid_sha256"]].append(game)
    maps = {key: {"seeds": sorted({row["seed"] for row in rows}), "games": len(rows),
                  **{model: map_report(rows, model) for model in BOSS_MODELS}}
            for key, rows in layouts.items()}
    models = {}
    for model in BOSS_MODELS:
        results = [row[model] for row in maps.values()]
        models[model] = {
            "frame_metrics": {group: means(row["frame_metrics"][group] for row in results) for group in GROUPS},
            "frame_counts": {group: summed(row["frame_counts"][group] for row in results) for group in GROUPS},
            "threat_counts": summed(row["threat_counts"] for row in results),
            "boundary_clips": summed(row["boundary_clips"] for row in results),
            **{key: means(row[key] for row in results) for key in
               ("threat_metrics", "opening_metrics", "closed_loop_metrics")},
        }
    return models, maps


def evaluate(entries, models, closed_loop):
    probes = set()
    samples, games = [], []
    for entry in entries:
        replay, trace = read_trace(entry)
        by_tick = defaultdict(list)
        events, coverage = trace.threats()
        for event in events:
            by_tick[event["tick"]].append(event)
        row = {key: entry[key] for key in ("id", "target_side", "seed", "grid_sha256", "version_id")}
        row["threat_coverage"] = coverage
        if closed_loop and entry["version_id"] is not None:
            probes.add(entry["version_id"])
        samples.append((replay, trace, threat_frames(trace), by_tick))
        games.append(row)
    for probe in probes:
        versions.verify(ROOT, probe)
    reruns = defaultdict(list)
    for name, (folder, _) in models.items():
        with local_factory(folder) as factory:
            for index, ((replay, trace, danger, events), row) in enumerate(zip(samples, games, strict=True)):
                row[name] = {"frame_counts": frame_counts(trace, factory, danger),
                             "threat_counts": threat_counts(trace, factory, events),
                             "opening": opening(trace, factory)}
                if closed_loop and row["version_id"] is not None:
                    reruns[index].append(closed_game(replay, trace, factory, row["version_id"]))
    for index, runs in reruns.items():
        replay, trace, *_ = samples[index]
        distances = common_alive_distances(replay, runs)
        for name, run, distance in zip(BOSS_MODELS, runs, distances, strict=True):
            games[index][name]["closed_loop"] = paired_game(replay, run, trace.side, distance)
    return games


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=Path(__file__).with_name("manifest.json"))
    parser.add_argument("--baseline", required=True, help="v31 快照 ID、快照目录或 files 路径")
    parser.add_argument("--candidate", required=True, help="候选策略目录或快照 ID")
    parser.add_argument("--split", choices=SPLITS, default="dev")
    parser.add_argument("--development-report", type=Path, help="仅盲测需要，核对开发集已评估的版本")
    parser.add_argument("--closed-loop", action="store_true", help="有冻结探针快照的对局另做 SDK 整局复跑")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    models = {name: find_model(getattr(args, name)) for name in BOSS_MODELS}
    run = {"model_ids": {name: identity for name, (_, identity) in models.items()},
           "manifest_sha256": hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
           "evaluator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           "closed_loop": args.closed_loop}
    if args.split == "blind":
        if args.development_report is None:
            parser.error("--split blind 需要 --development-report")
        development = read_json(args.development_report)
        if development["split"] != "dev" or development["run"] != run:
            parser.error("候选、基准、清单、评估脚本或闭环设置与开发报告不一致")
    entries = read_manifest(args.manifest)[args.split]
    if not entries:
        parser.error(f"{args.split} 没有可评估对局")
    games = evaluate(entries, models, args.closed_loop)
    if any(find_model(str(folder))[1] != identity for folder, identity in models.values()):
        raise ValueError("评估期间策略文件发生变更")
    aggregate_models, maps = aggregate(games)
    report = {"split": args.split, "run": run, "replays": len(games), "layouts": len(maps),
              "closed_loop_replays": sum("closed_loop" in row["baseline"] for row in games),
              "method": {
                  "frame": "逐帧按实际历史向两个模型提供同一个由回放重建的 SDK 观测。执行模型动作及从回放反推的对手动作，以 SDK 实际位置及角度比较。回放位置精度为 0.01 格，动作、碰撞和上一帧动作来源需推断。",
                  "fire": "动作前剩余装填为 0 或 1 帧时计实际开火。精确率、召回率和 F1 仅对存在真实开火的地图做宏平均。在这些图上无预测开火的精确率计 0。无真实开火的图仍计其假阳性率。近距使用动作前欧氏距离 ≤3 格。",
                  "threat": "场上来弹按 SDK 子步检测，原地半秒内会中弹时该帧入组。逐弹另计首次发现威胁，同起点 SDK 闭环半秒，对手每帧末位置还原，模型预热最近 20 帧。省略出膛即命中的炮弹和无完整后续窗口的事件。逐弹命中一致率仅计效应可归因的事件。",
                  "opening": "前 3 秒同出生起点跑 SDK，终极陪练自行决策，对手每帧末恢复官网状态。起步为距离出生点首次超过 0.05 格。窗口内未起步时记录删失和误差下界。",
                  "closed_loop": "有可校验版本的冻结探针配对复跑。使用官网地图、出生侧、局号和双方名称。中弹、死亡与时长比较整局，路程和交战距离使用官网、基准及候选都存活的共同窗口。",
                  "boundary_clips": "允许合法字段出现不超过 2⁻²³ 的动作边界越界，即 float32 在 1.0 处相邻数的间隔。动作按 SDK 原生裁剪。逐帧、已计分分支和闭环分别记录次数，其他无效动作使评估失败。",
                  "weights": "逐帧和逐弹先按布局汇总，开局与整局的对局指标先在布局内取均值，再对有该指标的各布局等权。三个分组的地图种子和墙格布局分别互斥。",
              }, "models": aggregate_models, "maps": maps, "games": games}
    write_json(args.output, report)
    print(args.output)


if __name__ == "__main__":
    main()
