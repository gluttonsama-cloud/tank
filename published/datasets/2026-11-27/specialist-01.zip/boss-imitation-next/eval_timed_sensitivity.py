"""Measure sensitivity to the official probe's first confirmed action source frame."""

import argparse
import hashlib
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from functools import partial
from pathlib import Path
from unittest.mock import patch

import eval_trajectory
from eval_round import (
    ROOT,
    CheckedBot,
    find_model,
    means,
    read_json,
    read_manifest,
    versions,
    write_json,
)
from prepare_trajectory_followup import BLIND_SEEDS
from seedcup.game.engine import SIDES, STILL
from seedcup.game.replay import ReplayRecorder
from seedcup.game.runner import play


class DelayedProbe(CheckedBot):
    """Update probe state on every SDK observation and apply neutral actions until release."""

    def decide(self, obs):
        action = super().decide(obs)
        return STILL.copy() if obs["frame"] < self.first_scored_tick else action


def delayed_game(replay, trace, factory, probe_id, *, delays):
    boss = CheckedBot(factory(), trace, "闭环陪练", return_raw=True)
    probe = versions.load_bot(ROOT, probe_id)
    checked_probe = DelayedProbe(
        probe, trace, "闭环探针", first_scored_tick=delays[trace.meta["id"]], return_raw=True,
    )
    bots = (boss, checked_probe) if trace.side == 0 else (checked_probe, boss)
    recorder = ReplayRecorder(trace.game_map, trace.meta)
    names = tuple(trace.meta[side]["name"] for side in SIDES)
    try:
        game = play(trace.game_map, bots, names, recorder=recorder, game_no=trace.meta["game"])
    finally:
        if hasattr(probe, "close"):
            probe.close()
    if game.violations != [item.boundary_clips for item in bots]:
        raise ValueError(f"回放 {trace.meta['id']} 的闭环对局有未归因的违规动作 {game.violations}")
    local = recorder.to_dict(game.result.to_dict())
    if local["frames"][0][:4] != replay["frames"][0][:4]:
        raise ValueError(f"回放 {trace.meta['id']} 的闭环初始状态与官网不一致")
    return local


def source_frame(entry):
    timing = entry["sdk_timing"]
    first = timing["first_observation_frame"]
    confirmed = timing["first_confirmed_source_frame"]
    if type(first) is not int or type(confirmed) is not int or not 0 <= first <= confirmed:
        raise ValueError(f"回放 {entry['id']} 的首次观测或已确认源帧无效")
    return confirmed


def evaluate_layout(task):
    entries, _ = task
    delays = {entry["id"]: source_frame(entry) for entry in entries}
    # Supply the alternative runner within this worker and reuse every trajectory metric.
    run = partial(delayed_game, delays=delays)
    with patch.object(eval_trajectory, "closed_game", run):
        rows = eval_trajectory.report_layout(task)
    return [row | {"probe_neutral_until_source_frame": delays[row["replay_id"]]} for row in rows]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--models", nargs=3, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    locations = dict(find_model(name)[::-1] for name in args.models)
    if len(locations) != len(args.models):
        parser.error("需要三个不同的策略快照")
    entries = read_manifest(args.manifest)["blind"]
    expected = Counter({(seed, side): 4 for seed in BLIND_SEEDS for side in SIDES})
    if Counter((row["seed"], row["target_side"]) for row in entries) != expected:
        parser.error("验收需要两张指定新地图各红蓝4局")
    for model, folder in locations.items():
        provenance = read_json(folder / "training.json")
        for field in ("id", "seed", "sha256"):
            frozen = {row[field] for group in ("train", "holdout") for row in provenance[group]}
            if frozen & {row[field] for row in entries}:
                parser.error(f"{model} 已使用本轮验收数据 {field}")
    for probe in {entry["version_id"] for entry in entries}:
        versions.verify(ROOT, probe)
    groups = defaultdict(list)
    for entry in entries:
        source_frame(entry)
        groups[entry["grid_sha256"]].append(entry)
    if len(groups) != len(BLIND_SEEDS):
        parser.error("每个验收种子需对应一张独立地图")

    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        games = []
        for rows in pool.map(evaluate_layout, [(rows, locations) for rows in groups.values()]):
            games.append(rows)
            print(f"{rows[0]['seed']}: {len(rows)} completed", flush=True)
    layouts = {
        rows[0]["layout"]: {model: means(game["runs"][model]["metrics"] for game in rows) for model in locations}
        for rows in games
    }
    write_json(args.output, {
        "report": {
            "manifest_sha256": hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
            "split": "blind", "replays": len(entries), "layouts": len(groups), "map_weighting": "equal",
            "common_alive_median_range": True, "approach_threshold_cells": 4, "retreat_threshold_cells": 6,
            "retreat_time_is_relative_to_approach": True,
            "event_mae_conditions_on_observed_event_in_both_games": True,
            "probe_neutral_before": "first_confirmed_source_frame",
            "probe_decision_history_from_frame": 0,
            "boss_decision_and_action_from_frame": 0,
        },
        "aggregate": {model: means(layout[model] for layout in layouts.values()) for model in locations},
        "layouts": layouts,
        "event_coverage": eval_trajectory.event_coverage(games, locations),
        "games": [game for rows in games for game in rows],
    })


if __name__ == "__main__":
    main()
