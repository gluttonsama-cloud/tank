from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'shot41o0.py').read_text()
for penalty in (.2,1,3):
 for cone in (0,.2,.8):
  text=f'''                if visible:
                    ex,ey=self.previous
                    if not clear_shot(self.walls,px,py,ex,ey):
                        utility-={penalty}
                    utility-={cone}*abs(delta(bearing,heading))/90
'''
  (d/f'keep{int(penalty*10)}c{int(cone*10)}.py').write_text(s.replace('                if visible and ready',text+'                if visible and ready'))
