from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'base.py').read_text()
for gap in (7,14,99):
 for steps in (1,3,6):
  # While reloading, step toward a position from which the enemy is visible
  # across a wider angular interval instead of remaining on a grazing line.
  a=s.index('        elif not center_visible')
  b=s.index('        elif cooldown',a)
  block=f'''        elif cooldown>.25 and dist>6 and dist<{gap}:
            best=None
            for offset in (0,-35,35,-70,70):
                direction=radians(bearing+offset)
                for sign in (1,-1):
                    dx,dy=sign*.25*cos(direction),sign*.25*sin(direction)
                    quality=0
                    for step in range(1,{steps}+1):
                        px,py=x+step*dx,y+step*dy
                        if not self.free(px,py):
                            quality-=2
                            break
                        for width in (-.45,0,.45):
                            tx=ex+width*(ey-y)/dist
                            ty=ey-width*(ex-x)/dist
                            quality+=int(clear_shot(self.walls,px,py,tx,ty))
                    quality-=abs(offset)*.002
                    quality+=.05*sign
                    if best is None or quality>best[0]:best=quality,offset,sign
            if center_visible and clear_shot(self.walls,x,y,ex+.45*(ey-y)/dist,ey-.45*(ex-x)/dist) and clear_shot(self.walls,x,y,ex-.45*(ey-y)/dist,ey+.45*(ex-x)/dist):
                target,speed=bearing,0
            else:
                target,speed=bearing+best[1],best[2]
'''
  (d/f'wide{gap}s{steps}.py').write_text(s[:a]+block+s[a:])
