from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'snap0w20.py').read_text()
for step in (.4,.8,1.25):
 for margin in (0,.2):
  insert=f'''        best=None
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(.707,.707),(-.707,.707),(.707,-.707),(-.707,-.707)):
            px,py=x+{step}*dx,y+{step}*dy
            if not self.free(px,py) or not self.free((x+px)/2,(y+py)/2):continue
            length=hypot(ex-px,ey-py)
            if length<1:continue
            offx,offy={margin}*(ey-py)/length,{margin}*(px-ex)/length
            if clear_shot(self.walls,px,py,ex+offx,ey+offy) and clear_shot(self.walls,px,py,ex-offx,ey-offy):
                diff=abs(delta(angle(dx,dy),self.body_heading))
                cost=min(diff,180-diff)+.15*abs(delta(angle(ex-px,ey-py),self.body_heading))
                if best is None or cost<best[0]:best=cost,px,py
        if best:return best[1],best[2]
'''
  t=s.replace('        start=int(x),int(y)',insert+'        start=int(x),int(y)').replace('        ex, ey = enemy', '        self.body_heading=heading\n        ex, ey = enemy')
  (d/f'spot{int(step*100)}m{int(margin*100)}.py').write_text(t)
