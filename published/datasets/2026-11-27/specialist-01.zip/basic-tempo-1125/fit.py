from base import Lancer,clear_shot
from seedcup.game.bots import BaselineBot
from tank.simulation import run_match
from concurrent.futures import ProcessPoolExecutor
from collections import defaultdict
import json,random
from pathlib import Path
d=Path(__file__).resolve().parent
exec((d/'features.txt').read_text(encoding='utf-8-sig'))
def job(task):
    seed,side=task;trace=[]
    class Meter(Lancer):
        def decide(self,o):
            x,y=o['self']['x'],o['self']['y']; e=o['enemy'];ex,ey,eh=e['x'],e['y'],e['heading']
            vx,vy=(0,0) if not self.previous else (ex-self.previous[0],ey-self.previous[1])
            f=motion_features(self,x,y,ex,ey,eh,vx,vy,getattr(self,'old_eh',eh))
            self.old_eh=eh;trace.append((ex,ey,*f))
            return super().decide(o)
    bots=[Meter(),BaselineBot()]
    if side:bots.reverse()
    run_match(*bots,seed,0)
    agg=defaultdict(lambda:[0,0.,0.])
    for i,(x,y,k,t,dx,dy) in enumerate(trace):
        if i+t>=len(trace):continue
        tx,ty=trace[i+t][:2];mx,my=tx-x,ty-y
        for key in (k,k[:5],k[:3]):
            r=agg[key];r[0]+=1;r[1]+=(mx*dx+my*dy)/t;r[2]+=(-mx*dy+my*dx)/t
    return dict(agg)
if __name__=='__main__':
    seeds=random.Random(3421).sample(range(35000000,36000000),600)
    with ProcessPoolExecutor(8) as pool:
        agg=defaultdict(lambda:[0,0.,0.])
        for data in pool.map(job,[(s,i) for s in seeds for i in (0,1)],chunksize=5):
            for key,row in data.items():
                for j in range(3):agg[key][j]+=row[j]
    model={str(k):[round(r[1]/r[0],5),round(r[2]/r[0],5)] for k,r in agg.items() if r[0]>=16}
    (d/'motion.json').write_text(json.dumps(model))
    print(sum(r[0] for k,r in agg.items() if len(k)==7),len(model))
