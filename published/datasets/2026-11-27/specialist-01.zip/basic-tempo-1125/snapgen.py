from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'keep2c0.py').read_text()
a=s.index('        fire=False');b=s.index('        return {"forward":',a)
helper=s[s.index('            direction=radians',a):b]
helper=helper.replace('expected_x','tx0').replace('expected_y','ty0').replace('                fire=','                return ')
helper='    def connects(self,x,y,heading,turn,speed,tx0,ty0):\n'+''.join(line[4:] for line in helper.splitlines(keepends=True))+'        return False\n\n'
s=s[:a]+'''        fire=cooldown<=.1 and visible and self.connects(x,y,heading,turn,speed,expected_x,expected_y)
        if cooldown<=.1 and not fire and not incoming and not self.retreating and dist>MIN_DIST:
            direct=angle(expected_x-x,expected_y-y)
            if abs(delta(direct,heading)) < 23:
                for offset in OFFSETS:
                    aim=direct+offset/max(dist,1)*57.2958
                    adjustment=clamp(delta(aim,heading)/18,1)
                    for advance in (speed,0,1,-1):
                        if self.connects(x,y,heading,adjustment,advance,expected_x,expected_y):
                            return {"forward":advance,"turn":adjustment,"fire":True}
'''+s[b:]
s=s.replace('    def decide(',helper+'    def decide(')
for gap in (0,6,10):
 for width in (.2,.35):
  (d/f'snap{gap}w{int(width*100)}.py').write_text(s.replace('MIN_DIST',str(gap)).replace('OFFSETS',str((0,width,-width))))
