from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'base.py').read_text()
for n in (3,6):
 for radius in (3,6,10):
  block=f'''        best=q
        for _ in range({n}):
            if q==goal:break
            q=min(self.links[q],key=self.distances.__getitem__)
            dx,dy=q[0]+.5-x,q[1]+.5-y
            steps=max(1,ceil(hypot(dx,dy)*4))
            if not all(self.free(x+dx*i/steps,y+dy*i/steps) for i in range(1,steps+1)):break
            best=q
        return best[0]+.5,best[1]+.5'''
  t=s.replace('        return q[0]+0.5, q[1]+0.5',block).replace('len(path)<6',f'len(path)<{radius}')
  (d/f'cut{n}r{radius}.py').write_text(t)
