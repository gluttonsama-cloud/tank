from pathlib import Path
import ast,json
d=Path(__file__).resolve().parent
s=(d/'cut6r6.py').read_text()
table={ast.literal_eval(k):v for k,v in json.loads((d/'motion.json').read_text()).items()}
func=(d/'features.txt').read_text(encoding='utf-8-sig')
s=s.replace('def angle(',f'MOTION = {table!r}\n\n'+func+'\ndef angle(')
for weight in (.35,.7,1):
 for mode in ('all','moving','edge'):
  cond={'all':'True','moving':'hypot(vx,vy)>.04','edge':'not k[0]'}[mode]
  block=f'''        eh=enemy["heading"]
        k,t,fx,fy=motion_features(self,x,y,ex,ey,eh,vx,vy,getattr(self,"prior_heading",eh))
        self.prior_heading=eh
        if {cond}:
            prediction=MOTION.get(k) or MOTION.get(k[:5]) or MOTION.get(k[:3])
            if prediction:
                along,across=prediction
                ax += {weight}*(ex+t*(along*fx-across*fy)-ax)
                ay += {weight}*(ey+t*(along*fy+across*fx)-ay)
'''
  (d/f'ml{int(weight*100)}{mode}.py').write_text(s.replace('        if not self.free(ax, ay):',block+'        if not self.free(ax, ay):'))
