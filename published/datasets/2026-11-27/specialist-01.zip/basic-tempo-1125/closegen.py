from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'ml100all.py').read_text()
for dist in (6,9,13,17):
 for pace in (.4,.75,1):
  t=s.replace('            target, speed = bearing, 0',f'''            target, speed = bearing, 0
            if center_visible and dist>{dist} and self.free(x+.5*(ex-x)/dist,y+.5*(ey-y)/dist):
                speed={pace}''')
  (d/f'close{dist}v{int(pace*100)}.py').write_text(t)
