from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'close13v75.py').read_text().replace('        center_visible = visible','        expected_x,expected_y=ax,ay\n        center_visible = visible')
for tol in (.32,.41,.5):
 for opportunistic in (0,1):
  b=f'''        fire=False
        if cooldown<=.1 and (visible or {bool(opportunistic)}):
            direction=radians(heading+turn*18)
            dx,dy=cos(direction),sin(direction)
            nx,ny=x+speed*.25*dx,y+speed*.25*dy
            if not self.free(nx,ny):
                if self.free(nx,y):ny=y
                elif self.free(x,ny):nx=x
                else:nx,ny=x,y
            sx,sy=nx+.5*dx,ny+.5*dy
            tx,ty=expected_x-sx,expected_y-sy
            along=tx*dx+ty*dy
            side=abs(tx*dy-ty*dx)
            if along>0 and side<{tol}:
                distance=max(.2,ceil((along-max(0,.42**2-side**2)**.5)/.2)*.2)
                fire=ray_wall(self.walls,sx,sy,dx,dy,distance)>=distance
'''
  a=s.index('        fire = visible');z=s.index('        return {',a)
  (d/f'shot{int(tol*100)}o{opportunistic}.py').write_text(s[:a]+b+s[z:])
