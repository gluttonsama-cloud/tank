from run import *
names=['selected']+[p.stem for p in D.glob('contact[0-9]*.py')]
old=json.loads((D/'final-selected.json').read_text())
cases=[(r[1],r[2]) for r in old if r[5]<=90]
if __name__=='__main__':
 with ProcessPoolExecutor(8) as pool:g=list(pool.map(run,[(m,s,i,0) for m in names for s,i in cases],chunksize=4))
 for m in names:
  rows=[r for r in g if r[0]==m];print(m,len(rows),summary(rows),[r[4] for r in rows if r[1]==33642204 and r[2]==1])

