import json, math, random, sys
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from statistics import mean
from original import Lancer,clear_shot
from tank.simulation import run_match
from seedcup.game.bots import BaselineBot
D=Path(__file__).resolve().parent
def features(bot,x,y,ex,ey,vx,vy):
    dist=math.hypot(ex-x,ey-y)
    ticks=max(1,min(24,math.ceil((dist-.5-.42)/1.2)))
    speed=math.hypot(vx,vy)
    key=(int(clear_shot(bot.walls,x,y,ex,ey)),int(speed>.08), min(6,ticks//3),int(bot.free(ex+vx*3,ey+vy*3)))
    return ticks,key
def simulate(task):
    mode,seed,side=task
    trace=[]
    class Practice(Lancer):
        distance=0
        pos=None
        def decide(self,obs):
            m,e=obs['self'],obs['enemy']
            x,y=m['x'],m['y']
            if self.pos: self.distance+=math.dist(self.pos,(x,y))
            self.pos=x,y
            ex,ey=e['x'],e['y']
            vx,vy=(0,0) if self.previous is None else (ex-self.previous[0],ey-self.previous[1])
            if mode=='train' or mode=='audit':
                ticks,key=features(self,x,y,ex,ey,vx,vy)
                trace.append((ex,ey,vx,vy,ticks,key))
            return super().decide(obs)
    if mode in ('train','audit','original'): bot=Practice()
    else:
        import importlib
        class Meter(importlib.import_module(mode).Lancer):
            distance=0
            pos=None
            def decide(self,o):
                p=(o['self']['x'],o['self']['y'])
                if self.pos:self.distance+=math.dist(self.pos,p)
                self.pos=p
                return super().decide(o)
        bot=Meter()
    bots=[bot,BaselineBot()]
    if side:bots.reverse()
    m=run_match(*bots,seed,0); r=m['result'];sc=r['scores'][side];st=r['stats'][side]
    sums=defaultdict(lambda:[0,0,0,0,0])
    if trace:
        model=json.loads((D/'model.json').read_text()) if mode=='audit' else {}
        for i,(x,y,vx,vy,k,key) in enumerate(trace):
            if i+k>=len(trace):continue
            tx,ty=trace[i+k][:2];dx,dy=vx*k,vy*k
            a=sums[','.join(map(str,key))]
            a[0]+=1;a[1]+=dx*(tx-x)+dy*(ty-y);a[2]+=dx*dx+dy*dy
            if mode=='audit' and key[0] and key[1]:
                alpha=model.get(','.join(map(str,key)),1)
                a[3]+=math.hypot(x+dx-tx,y+dy-ty);a[4]+=math.hypot(x+alpha*dx-tx,y+alpha*dy-ty)
    return [mode,seed,side,sc['total'],sc['survive'],r['ticks']/10,st['hits'],st['shots'],bot.distance,int(m['winner']==side),dict(sums)]
if __name__=='__main__':
    phase=sys.argv[1]; n=int(sys.argv[2]); modes=sys.argv[3:]
    bounds={'train':(21000000,22000000),'dev':(22000000,23000000),'final':(23000000,24000000)}
    seeds=random.Random(6173).sample(range(*bounds[phase]),n)
    tasks=[(m,s,i) for m in modes for s in seeds for i in (0,1)]
    with ProcessPoolExecutor(6) as pool: rows=list(pool.map(simulate,tasks,chunksize=6))
    agg=defaultdict(lambda:[0]*5)
    for row in rows:
        for key,vals in row.pop().items():
            for i,v in enumerate(vals):agg[key][i]+=v
    if phase=='train':
        model={k:round(max(0,min(1.25,(a[1]+1)/(a[2]+1))),5) for k,a in agg.items()}
        (D/'model.json').write_text(json.dumps(model));print('samples',sum(a[0] for a in agg.values()))
    if 'audit' in modes:
        arr=[a for k,a in agg.items() if k.startswith('1,1,')]
        print('visible-moving prediction count/mean errors',sum(a[0] for a in arr),*[sum(a[i] for a in arr)/sum(a[0] for a in arr) for i in (3,4)])
    (D/(phase+'.json')).write_text(json.dumps(rows))
    for m in modes:
        g=[r for r in rows if r[0]==m]; print(m,len(g),*[round(mean(a[i] for a in g),3) for i in (3,4,5,8)],sum(a[6] for a in g),sum(a[7] for a in g),sum(a[9] for a in g))
