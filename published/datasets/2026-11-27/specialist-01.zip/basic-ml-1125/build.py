from pathlib import Path
import json
d=Path(__file__).resolve().parent
src=(d/'original.py').read_text(encoding='utf-8-sig')
coeff={tuple(map(int,k.split(','))):v for k,v in json.loads((d/'model.json').read_text()).items() if k.split(',')[1]=='1'}
ml=src.replace('from math import atan2','from math import ceil, atan2').replace('ZONE_LOOKAHEAD = 30','ZONE_LOOKAHEAD = 30\n\n# Fraction of constant-velocity displacement fitted on local SDK games.\nLEAD = '+repr(coeff)).replace('flight = min(14, dist/1.2)','''flight = max(1, min(24, ceil((dist-.92)/1.2)))
        if hypot(vx, vy) > .08:
            key = (int(clear_shot(self.walls, x, y, ex, ey)), 1, min(6, flight//3),
                   int(self.free(ex+vx*3, ey+vy*3)))
            flight *= LEAD.get(key, 1)''')
(d/'learned.py').write_text(ml,encoding='utf8')
for amp in (55,75,90):
 for window in (35,55):
  name=f'm{amp}w{window}'
  (d/(name+'.py')).write_text(ml.replace('bearing + best[1], -1',f'bearing + best[1], -{amp/100}').replace('cooldown <= 0.35',f'cooldown <= {window/100}'),encoding='utf8')
