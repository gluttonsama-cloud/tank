import sys
from pathlib import Path
from dataclasses import fields
from collections import Counter
import shutil
import json

D = Path(__file__).resolve().parent
ROOT = D.parents[1]
sys.path.insert(0,str(ROOT))
from training import fit_boss_replay_forecast as fit
from tank import versions
from tank.workspace import read_json,write_json

source=ROOT/'strategies/boss-specialist'
base=read_json(source/'base/forecast.json')
plans=[ROOT/'.local/training/jobs'/job/'output/plan.json' for job in fit.PRIOR_JOBS]
seeds,grids=fit.reservations(ROOT,base,plans,[145420624,196875341,196875357])
groups,skipped=fit.grouped_entries(read_json(D/'manifest.json'),seeds,grids,expand_development=True)
selected={}
for split in fit.SPLITS:
    games=fit.load_games(ROOT,groups[split],skipped)
    close={}
    for key,entries in games.items():
        for entry,s in entries:
            mask=s.features[:,5]<=4/15
            if mask.any():
                cut=fit.Samples(*(getattr(s,f.name)[mask] for f in fields(s)))
                close.setdefault(key,[]).append((entry,cut))
    selected[split]=close
proj,bias,models=fit.fit_candidates(selected['train'],base)
dev=fit.metrics(selected['development'],proj,bias,models)
winner=min((n for n in models if n!='v4'),key=lambda n:dev[n]['fired']['lateral_mae_cells'])
blind=fit.metrics(selected['blind'],proj,bias,{k:models[k] for k in ('v4',winner)})
src={k:fit.split_sources(v) for k,v in selected.items()}
report={'sources':src,'development':dev,'blind':blind,'selected':winner}
write_json(D/'fit-report.json',report)
dest=D/'candidate'
shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copyfile(source/'base/boss_forecast.py',dest/'boss_forecast.py')
write_json(dest/'close.json',dict(projection=proj.tolist(),bias=bias.tolist(),coef=models[winner].tolist()))
with (dest/'bot.py').open('a',encoding='utf-8') as f:
    f.write('''
from math import hypot
from boss_forecast import make_predictor
from boss_specialist_policy import flight_ticks, angle_delta, bearing, clamp, motion, shot_error, incoming_paths
from seedcup.game import rules
close_forecast = make_predictor(json.loads((ROOT / "close.json").read_text(encoding="utf-8")))

class OfficialClose(Specialist):
    def on_match_start(self, info):
        super().on_match_start(info)
        self.previous_enemy = None

    def decide(self, obs):
        action = super().decide(obs)
        me, foe = obs["self"], obs["enemy"]
        x,y = me["x"], me["y"]
        ex,ey = foe["x"],foe["y"]
        frame = obs["frame"]
        prev = self.previous_enemy
        self.previous_enemy = (ex,ey,frame)
        dist = hypot(ex-x,ey-y)
        if not prev or frame <= prev[2] or dist > 4 or me["reload"] > rules.DT or not self._local_arena.aim_clear(x,y,ex,ey):
            return action
        if incoming_paths(self._local_arena,x,y,obs["shells"]):
            return action
        aim=close_forecast(obs,(ex-prev[0])/(frame-prev[2]),(ey-prev[1])/(frame-prev[2]),flight_ticks(dist))
        px,py=self._local_arena.move(x,y,*motion(me["heading"],action["turn"],action["forward"]),(ex,ey))
        turn=clamp(angle_delta(bearing(aim[0]-px,aim[1]-py),me["heading"])/(rules.TURN_RATE*rules.DT))
        err=shot_error(self._local_arena,(x,y),me["heading"],turn,action["forward"],(ex,ey),aim)
        return action | {"turn":turn,"fire":True} if err < .22 else action
''')
write_json(dest/'submission.json',{'runtime':'python','entrypoint':'bot.py:OfficialClose'})
v=versions.create_from_directory(ROOT,dest,'boss-specialist','官网终极档回放，四格内预测瞄点')
write_json(D/'candidate.json',{'id':v['id']})
print(v['id'],{k:len(rows) for k,rows in src.items()},winner,{k:m['fired']['lateral_mae_cells'] for k,m in blind.items()},flush=True)
