from tank import process_bot
