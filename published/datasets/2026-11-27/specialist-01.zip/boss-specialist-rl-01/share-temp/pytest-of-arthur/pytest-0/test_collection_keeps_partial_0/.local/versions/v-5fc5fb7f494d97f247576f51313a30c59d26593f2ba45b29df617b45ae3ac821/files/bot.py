from seedcup import Bot
import numpy as np
class Demo(Bot):
    def decide(self, obs):
        return {"forward": float(np.float64(0)), "turn": 0, "fire": False}
