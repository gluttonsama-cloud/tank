from subprocess import run as start
start(['python', 'extras/tool.py'])
