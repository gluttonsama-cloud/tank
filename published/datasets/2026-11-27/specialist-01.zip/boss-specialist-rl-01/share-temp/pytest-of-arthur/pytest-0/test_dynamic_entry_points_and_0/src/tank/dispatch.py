import subprocess, sys
subprocess.run([sys.executable, '-m', 'tank.worker'])
