from importlib import import_module as load
load('tank.worker')
