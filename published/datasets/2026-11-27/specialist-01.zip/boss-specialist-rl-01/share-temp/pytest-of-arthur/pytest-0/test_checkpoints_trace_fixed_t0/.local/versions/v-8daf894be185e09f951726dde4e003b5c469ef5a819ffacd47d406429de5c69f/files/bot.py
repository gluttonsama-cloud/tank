# sparring
from seedcup import Bot
class Strategy(Bot):
    def decide(self, obs):
        return {'forward': 0, 'turn': 0, 'fire': False}
