from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import random
from statistics import mean

from seedcup.client.loader import load_bot
from tank import catalog, versions
from tank.simulation import run_match
from tank.workspace import read_json, write_json

ROOT = Path(__file__).resolve().parents[2]
DIR = Path(__file__).resolve().parent
OPPONENT = "v-8eafb7605945a640bfaf4dd85d6920dc75df3fcd5fa42a32ada7d7dcbd41af26"


def factory(vid):
    folder = versions.snapshot_data(ROOT, vid)
    entry = read_json(folder / "submission.json")["entrypoint"]
    return load_bot(str(folder / entry))


def setup(ids):
    global factories, boss
    boss = factory(OPPONENT)
    factories = {vid: factory(vid) for vid in ids}


def game(case):
    name, vid, seed, side = case
    bots = [factories[vid](), boss()]
    if side:
        bots.reverse()
    res = run_match(*bots,seed,side)
    return dict(model=name, seed=seed, side=side, score=res["scores"][side], won=res["winner"]==side,
                seconds=res["result"]["seconds"], violations=res["result"].get("violations"))


if __name__ == "__main__":
    ids = [v["id"] for v in versions.list_versions(ROOT) if v["id"] != "baseline"]
    labels = catalog.project_labels(ROOT, ids)
    interested = {"lancer-v1","lancer-v3","lancer-v5","lancer-v6","lancer-v7","basic-specialist-v7"}
    models = {name:v for v,ls in labels.items() for label in ls
              if (name := f"{label['id']}-v{label['number']}") in interested}
    assert set(models)==interested
    for m in [*models.values(), OPPONENT]:
        versions.verify(ROOT,m)
    seeds=random.Random(11251831).sample(range(1630000000,1640000000),12)
    write_json(DIR/"screen-plan.json", dict(opponent=OPPONENT,models=models,seeds=seeds))
    cases=[(name,vid,seed,side) for seed in seeds for name,vid in models.items() for side in (0,1)]
    with ProcessPoolExecutor(max_workers=12,initializer=setup,initargs=(list(models.values()),)) as pool:
        results=list(pool.map(game,cases,chunksize=2))
    summary=[]
    for name,vid in models.items():
        g=[x for x in results if x['model']==name]
        summary.append(dict(name=name,id=vid,mean=mean(x['score'] for x in g),wins=sum(x['won'] for x in g),
                            games=len(g)))
    summary.sort(key=lambda x:-x['mean'])
    write_json(DIR/"screen.json",dict(summary=summary,games=results))
    print(summary)
