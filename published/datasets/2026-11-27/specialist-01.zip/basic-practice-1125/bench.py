from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from collections import defaultdict
from statistics import mean
from importlib.util import spec_from_file_location,module_from_spec
import sys,json,random
from tank.simulation import run_match
from seedcup.game.bots import BaselineBot
root=Path(__file__).resolve().parent
def gen():
    src=(root/'base.py').read_text(encoding='utf8')
    for c in (3,5,7):
        for orbit in (55,85,110):
            code=src.replace('cooldown <= .55',f'cooldown <= {c/10}').replace('70 if dist > 10 else 105',str(orbit)).replace('abs(diff) > 90','abs(diff) > 90 and (not visible or self.retreating)').replace('along < 10','along < 14').replace(' < 1.1:', ' < 1.6:')
            (root/f'v{c}_{orbit}.py').write_text(code,encoding='utf8')
def run(task):
    name,seed,side,rep=task
    spec=spec_from_file_location('candidate',root/(name+'.py'))
    mod=module_from_spec(spec);spec.loader.exec_module(mod)
    bots=[mod.Lancer(), BaselineBot()]
    if side: bots.reverse()
    m=run_match(*bots,seed,rep)
    score=m['result']['scores'][side]
    return [name,seed,side,rep,score['total'],score['survive'],score['time'],int(m['winner']==side)]
if __name__=='__main__':
    phase=sys.argv[1]
    if phase=='fit': gen()
    seeds=(json.loads(Path('suites/full.json').read_text())['seeds'] if phase=='fit' else random.Random({'test':178239,'dev':11255,'final':781335}.get(phase,62)).sample(range(100000,20000000),int(sys.argv[2])))
    names=sys.argv[3:] or ['base']+[p.stem for p in sorted(root.glob('v*.py'))]
    tasks=[(n,s,i,r) for n in names for s in seeds for i in (0,1) for r in range(2 if phase=='final' else 1)]
    with ProcessPoolExecutor(max_workers=6) as pool: rows=list(pool.map(run,tasks,chunksize=4))
    (root/(phase+'.json')).write_text(json.dumps(rows))
    for name in names:
        sub=[r for r in rows if r[0]==name]
        print(name,len(sub),*[round(mean(r[c] for r in sub),2) for c in range(4,7)],sum(r[7] for r in sub), min(r[4] for r in sub))
