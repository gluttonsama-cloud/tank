"""Learned close-range movement on top of the team's frozen grid navigator."""
from math import atan2, cos, degrees, hypot, radians, sin
import json
from pathlib import Path

from navigation import Lancer, angle, clamp, clear_shot, delta


class Duelist(Lancer):
    def __init__(self, weights=None):
        if weights is None:
            weights = json.loads(Path(__file__).with_name("weights.json").read_text())
        self.weights = weights

    def on_match_start(self, info):
        super().on_match_start(info)
        self.motion = 0.0
        self.last_enemy_shot = -100
        self.previous_hp = 100

    def decide(self, obs):
        action = self.movement(obs)
        if "forecast" not in self.weights:
            return action
        w = self.weights
        me, enemy = obs["self"], obs["enemy"]
        if (self.motion < w["pursuit"] or self.retreating or
                obs["frame"] - self.last_enemy_shot < 15 - w["warning"]):
            return action
        x, y, heading = me["x"], me["y"], me["heading"]
        dx, dy = x - enemy["x"], y - enemy["y"]
        distance = hypot(dx, dy)
        if not 1 < distance < w["forecast"] or not clear_shot(self.walls, x, y, enemy["x"], enemy["y"]):
            return action
        firing_angle = angle(dx, dy)
        if abs(delta(firing_angle, enemy["heading"])) > w["field"]:
            return action
        ux, uy = dx / distance, dy / distance
        delay = max(0, 15 - (obs["frame"] - self.last_enemy_shot))
        horizon = min(9, 1 + int((distance-.5)/1.2 + delay))
        proposed_turn, proposed_speed = action["turn"], action["forward"]
        best = (-1000, proposed_turn, proposed_speed)
        for turn in dict.fromkeys((proposed_turn, -1., 0., 1.)):
            for speed in dict.fromkeys((proposed_speed, -1., 1.)):
                px, py, h = x, y, heading
                for _ in range(horizon):
                    h += turn * 18
                    nx = px + speed*.25*cos(radians(h))
                    ny = py + speed*.25*sin(radians(h))
                    if self.free(nx, ny):
                        px, py = nx, ny
                lateral = abs((px-x)*uy - (py-y)*ux)
                utility = min(lateral, w["clearance"]) - .07*abs(turn-proposed_turn) - .05*abs(speed-proposed_speed)
                if action["fire"] and me["reload"] <= .1 and abs(turn-proposed_turn) > .05:
                    utility -= w["trigger"]
                if utility > best[0]:
                    best = utility, turn, speed
        return {"turn": best[1], "forward": best[2], "fire": action["fire"] and best[1] == proposed_turn}

    def movement(self, obs):
        previous = self.previous
        action = super().decide(obs)
        w = self.weights
        if not w["enabled"] or self.retreating:
            return action
        me, other = obs["self"], obs["enemy"]
        x, y = me["x"], me["y"]
        dx, dy = other["x"] - x, other["y"] - y
        distance = hypot(dx, dy)
        if "guard" in w:
            recent = any(not sh["mine"] and hypot(sh["x"] - other["x"], sh["y"] - other["y"]) < 2
                         for sh in obs["shells"])
            if obs["frame"] - self.last_enemy_shot >= 14 and (
                    recent or (distance < 3 and self.previous_hp - me["hp"] >= 9)):
                self.last_enemy_shot = obs["frame"] - 1
            self.previous_hp = me["hp"]
        if previous is not None:
            movement = hypot(other["x"] - previous[0], other["y"] - previous[1])
            self.motion = .92 * self.motion + .08 * movement
        if not clear_shot(self.walls, x, y, other["x"], other["y"]):
            return action
        for shell in obs["shells"]:
            if shell["mine"]:
                continue
            sx, sy = x - shell["x"], y - shell["y"]
            along = sx * shell["dx"] + sy * shell["dy"]
            across = abs(sx * shell["dy"] - sy * shell["dx"])
            if 0 < along < 10 and across < 1.1:
                return action

        if previous is not None:
            lead = min(12, max(0, distance - .5) / 1.2) * w["lead"]
            dx += (other["x"] - previous[0]) * lead
            dy += (other["y"] - previous[1]) * lead
        bearing = angle(dx, dy)
        error = delta(bearing, me["heading"])
        # Allow enough frames to face the target by the time reload finishes.
        aim_time = max(0, abs(error) / 180) + w["setup"]
        if "pursuit" in w and self.motion >= w["pursuit"]:
            if "arc" in w and me["reload"] > aim_time:
                # Advance along the ring around the rival instead of crossing its occupied cell.
                radial = angle(x-other["x"], y-other["y"])
                remaining = delta(other["heading"] + 180, radial)
                ahead = radians(radial + clamp(remaining, w["arc"]))
                ready = obs["frame"] - self.last_enemy_shot >= 15 - w["anticipation"]
                radius = w["outer"] if ready and abs(remaining) > 90 else w["inner"]
                wx = other["x"] + radius*cos(ahead)
                wy = other["y"] + radius*sin(ahead)
                target = angle(wx-x, wy-y)
                change = delta(target, me["heading"])
                speed = min(1, hypot(wx-x, wy-y)*3)
                if abs(change) > 90:
                    change = delta(target+180, me["heading"])
                    speed = -speed
                step = radians(me["heading"] + clamp(change, 18))
                if self.free(x + speed*.4*cos(step), y + speed*.4*sin(step)):
                    return {"forward": speed, "turn": clamp(change/18,1), "fire": False}
            if "guard" in w and obs["frame"] - self.last_enemy_shot >= 15 - w["anticipation"]:
                enemy_error = delta(angle(x-other["x"], y-other["y"]), other["heading"])
                if (abs(enemy_error) < w["cone"] and distance < w["guard"]
                        and (me["reload"] > .1 or abs(error) > 18)):
                    target = bearing + (w["escape_angle"] if enemy_error < 0 else -w["escape_angle"])
                    change = delta(target, me["heading"])
                    forward = 1.0
                    if abs(change) > 90:
                        change = delta(target+180, me["heading"])
                        forward = -1.0
                    if self.free(x + .4*forward*cos(radians(me["heading"] + clamp(change,18))),
                                 y + .4*forward*sin(radians(me["heading"] + clamp(change,18)))):
                        return {"forward": forward, "turn": clamp(change/18,1), "fire": False}
            if me["reload"] > aim_time:
                # Steer toward a point beside the moving rival during reload.
                # The signed cross product picks the nearer side in arena coordinates.
                h = radians(other["heading"])
                flank = w["flank"] if dy*cos(h) - dx*sin(h) < 0 else -w["flank"]
                trail = w.get("trail", 0.0)
                target = degrees(atan2(dy + flank*cos(h) - trail*sin(h),
                                       dx - flank*sin(h) - trail*cos(h)))
                change = delta(target, me["heading"])
                forward = 1.0
                if abs(change) > 90:
                    change = delta(target + 180, me["heading"])
                    forward = -1.0
                return {"forward": forward, "turn": clamp(change / 18, 1), "fire": False}
            turn = clamp(error / 18, 1)
            return {"forward": clamp((distance-w["near"])*1.5, 1), "turn": turn,
                    "fire": abs(error-turn*18)*max(distance, 1) < 24}
        if me["reload"] > aim_time and distance < w["approach_range"]:
            return action
        turn = clamp(error / 18, 1)
        speed = clamp((distance - w["spacing"]) * w["gain"], 1)
        if abs(error) > 50:
            speed *= .25
        return {"forward": speed, "turn": turn,
                "fire": abs(error - turn * 18) * max(distance, 1) < 24}
