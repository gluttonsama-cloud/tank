from bot import Duelist as BasePolicy
