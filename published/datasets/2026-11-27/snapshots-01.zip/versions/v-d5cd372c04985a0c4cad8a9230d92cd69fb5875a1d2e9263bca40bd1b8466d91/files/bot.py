from pathlib import Path
import json
from boss_specialist_policy import load_strategy
from boss_local_policy import make_local_policy

ROOT = Path(__file__).resolve().parent
Specialist = make_local_policy(load_strategy(ROOT / "base"), load_strategy(ROOT / "replica"),
                               json.loads((ROOT / "weights.json").read_text(encoding="utf-8"))["params"])

from math import hypot
from boss_forecast import make_predictor
from boss_specialist_policy import flight_ticks, angle_delta, bearing, clamp, motion, shot_error, incoming_paths
from seedcup.game import rules
close_forecast = make_predictor(json.loads((ROOT / "close.json").read_text(encoding="utf-8")))

class OfficialClose(Specialist):
    def on_match_start(self, info):
        super().on_match_start(info)
        self.previous_enemy = None

    def decide(self, obs):
        action = super().decide(obs)
        me, foe = obs["self"], obs["enemy"]
        x,y = me["x"], me["y"]
        ex,ey = foe["x"],foe["y"]
        frame = obs["frame"]
        prev = self.previous_enemy
        self.previous_enemy = (ex,ey,frame)
        dist = hypot(ex-x,ey-y)
        if not prev or frame <= prev[2] or dist > 4 or me["reload"] > rules.DT or not self._local_arena.aim_clear(x,y,ex,ey):
            return action
        if incoming_paths(self._local_arena,x,y,obs["shells"]):
            return action
        aim=close_forecast(obs,(ex-prev[0])/(frame-prev[2]),(ey-prev[1])/(frame-prev[2]),flight_ticks(dist))
        px,py=self._local_arena.move(x,y,*motion(me["heading"],action["turn"],action["forward"]),(ex,ey))
        turn=clamp(angle_delta(bearing(aim[0]-px,aim[1]-py),me["heading"])/(rules.TURN_RATE*rules.DT))
        err=shot_error(self._local_arena,(x,y),me["heading"],turn,action["forward"],(ex,ey),aim)
        return action | {"turn":turn,"fire":True} if err < .22 else action
