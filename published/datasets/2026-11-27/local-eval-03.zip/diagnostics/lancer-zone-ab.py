import importlib.util
import json
from collections import defaultdict
from pathlib import Path
from seedcup.game.bots import BaselineBot
from tank.simulation import run_match
from tank.versions import snapshot_data

ROOT=Path.cwd()
IDS={
    'stable':'v-0081349ee9d189d06bc534ecdac22f731b4908714c90b45644a1962aea0583f5',
    'stable_fix':'v-d08ada40d3cb56bdb12068f9ef0b21b294824f362505c143310f27067b8c9d5b',
    'turn':'v-347bb1bc7deb8f248847596bcc9594f637c81178ab1b24da4defd5e5e015987f',
    'turn_fix':'v-db3d6c14e58892be0e84dc66eab38d2f50996ec53d18753cf7f93f80a51722ef',
}

def load(name, version):
    file=snapshot_data(ROOT,version)/'bot.py'
    spec=importlib.util.spec_from_file_location(name, file)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.Lancer

BOTS={k:load(k,v) for k,v in IDS.items()}|{'rookie':BaselineBot}

def sample(seed, side, bot, opponent):
    duel=[BOTS[bot](), BOTS[opponent]()]
    if side:
        duel.reverse()
    match=run_match(*duel,seed,0)
    st=match['result']['stats'][side]
    return {
        'seed':seed,'side':('red','blue')[side],'bot':bot,'enemy':opponent,'ticks':match['result']['ticks'],
        'zone_damage':st['zone_damage'],'combat_damage':match['result']['stats'][1-side]['damage'],
        'score':match['scores'][side],'won':match['winner']==side,'reason':match['result']['reason'],'hp':st['hp'],
    }

results=[]
for current, fixed, opponent in [('turn','turn_fix','turn'),('stable','stable_fix','turn'),('stable','stable_fix','rookie')]:
    for seed in (1200500144,42,22111,10391,19357,23827,35107,54679,61417,79001,94847,8981,7109,2026,818,3571,65001,771,727,922,143):
        for side in (0,1):
            results.extend([sample(seed,side,current,opponent),sample(seed,side,fixed,opponent)])
    group=[r for r in results if r['enemy']==opponent and r['bot'] in (current,fixed)]
    pairs=list(zip(group[::2],group[1::2],strict=True))
    long=[pair for pair in pairs if pair[0]['ticks']>400 and pair[1]['ticks']>400]
    for rows in (pairs,long):
        print(current,fixed,opponent,'pairs:',len(rows),[(sum(pair[k]['zone_damage'] for pair in rows),sum(pair[k]['combat_damage'] for pair in rows),round(sum(pair[k]['score'] for pair in rows),2),sum(pair[k]['won'] for pair in rows)) for k in (0,1)],flush=True)
    for row in group[:4]: print(row,flush=True)
    output=Path('.local/diagnostics/lancer-zone-ab.json')
    output.write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
