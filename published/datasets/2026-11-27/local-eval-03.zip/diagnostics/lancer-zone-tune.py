from concurrent.futures import ProcessPoolExecutor
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path
import json
from tank.simulation import run_match
from tank.versions import snapshot_data

ROOT=Path.cwd()
    

def load(name, version):
    spec=spec_from_file_location(name,snapshot_data(ROOT,version)/'bot.py')
    mod=module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.Lancer


def run(ctx):
    horizon, exit_margin, entry_margin, first_penalty, tick_penalty, gap_penalty=ctx
    head=(ROOT/'strategies/lancer/bot.py').read_text()
    for a,b in [
        ('ZONE_LOOKAHEAD = 20', f'ZONE_LOOKAHEAD = {horizon}'),
        ('1.1 if self.retreating else .6', f'{exit_margin} if self.retreating else {entry_margin}'),
        ('35 if tick == 1 and not already_outside else .6',f'{first_penalty} if tick == 1 and not already_outside else {tick_penalty}'),
        ('-future_radius)*1.6', f'-future_radius)*{gap_penalty}'),
    ]:
        assert head.count(a)==1,a
        head=head.replace(a,b)
    context={}
    exec(compile(head,'bot.py','exec'),context)
    candidate=context['Lancer']
    baseline=load('baseline','v-0081349ee9d189d06bc534ecdac22f731b4908714c90b45644a1962aea0583f5')
    turned=load('turned','v-347bb1bc7deb8f248847596bcc9594f637c81178ab1b24da4defd5e5e015987f')
    cases=[]
    for seed in (1200500144,42,22111,10391,19357,23827,35107,54679,61417,79001,94847,8981,7109,2026,818,3571,65001,771,727,922,143):
        for side in (0,1):
            pair=[candidate(), turned()]
            if side:
                pair.reverse()
            match=run_match(*pair,seed,0)
            res=match['result']
            cases.append((seed,side,res['ticks'],res['stats'][side]['zone_damage'],res['stats'][1-side]['damage'],match['scores'][side],match['winner']==side))
    print(ctx,[round(sum(case[i] for case in cases),2) for i in (3,4,5,6)],flush=True)
    out=ROOT/'.local/diagnostics'/('lancer-zonetune-'+'-'.join(map(str,ctx))+'.json')
    out.write_text(json.dumps(cases,indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':
    configs=[(20,1.1,.6,35,.6,1.6),(12,.85,.5,20,.6,1.6),(5,.6,.45,12,.4,1.3),(30,1.1,.6,26,.8,2), (12,.9,.6,9,.6,1.6), (0,.6,.5,15,.45,1)]
    with ProcessPoolExecutor(max_workers=6) as pool:
        list(pool.map(run,configs))
