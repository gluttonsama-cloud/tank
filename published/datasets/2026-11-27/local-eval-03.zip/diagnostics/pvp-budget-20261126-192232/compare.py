import sys, json, gzip, shutil, random, time
from pathlib import Path
from statistics import median, quantiles
root=Path.cwd()
sys.path.insert(0,str(root))
from tank import versions
from training.cycle_matches import GameCase,Trial,play,open_pool
from training.fit_boss_sparring import replay_observation
from training.boss_specialist_policy import load_strategy
from seedcup.game import generate_map,parse_action
from seedcup.game.runner import match_info
from seedcup.game.engine import STILL,action_fields

def main():
 out=Path(__file__).resolve().parent
 pool=json.loads((root/'.local/cycle/pvp/opponents.json').read_text())
 base=versions.snapshot_data(root,pool['router-v2'])
 source=out/'candidate';shutil.copytree(base,source)
 path=source/'policy_b/boss_local_policy.py'
 old=path.read_bytes();assert old.count(b'"budget_ms": None')==1
 path.write_bytes(old.replace(b'"budget_ms": None',b'"budget_ms": 6'))
 vid=versions.create_from_directory(root,source,'style-switch','天梯实验：切换后每帧瞄准搜索限时 6 毫秒')['id']
 paths={'v2':base,'6ms':versions.snapshot_data(root,vid)}
 timing={}; results=[]
 for key,folder in paths.items():
  rows=[]
  for mid in (25808,27485,27492,27531,27604,27608):
   entry=root/'.local/cycle/ladder';meta=json.loads((entry/'games'/f'{mid}.json').read_text())
   d=json.load(gzip.open(meta['replay_path']));s=int(meta['own_side']=='blue')
   durations=[]
   for rep in range(3):
    random.seed(mid);b=load_strategy(folder)();info=match_info(generate_map(d['map']['seed']),s,'参赛队伍'); del info['map']['seed'];b.on_match_start(info);a=STILL.copy()
    for frame in d['frames']:
     obs=replay_observation(frame,s)|dict(collision=False,last_action=a)
     t=time.perf_counter();a=action_fields(b.decide(obs));durations.append((time.perf_counter()-t)*1000);assert not parse_action(a)[1]
   rows.append(dict(mid=mid,ms=durations))
  timing[key]=rows
  flat=sorted(x for r in rows for x in r['ms'])
  print(key,'p99/max',round(quantiles(flat,n=100)[98],2), round(max(flat),2),flush=True)
 (out/'timing.json').write_text(json.dumps(timing))
 rng=random.Random(8194132)
 tasks=[];labels=[]
 for style in ('lancer-v7','old-main','holdout-orbit'):
  for idx in range(4):
   seed,ours,foe=[rng.getrandbits(30) for _ in range(3)]
   for side in (0,1):
    for key,folder in paths.items():
     tasks.append(Trial(style,str(folder),str(versions.snapshot_data(root,pool[style])),(GameCase(seed,side,ours,foe,1),)))
     labels.append(key)
 with open_pool(4) as executor:
  for key,row in zip(labels,executor.map(play,tasks),strict=True): results.append(dict(version=key,**row))
 (out/'paired.json').write_text(json.dumps(dict(candidate=vid,results=results)))
 for k in paths:
  print(k,[(s,sum(g['wins'][0] for g in results if g['style']==s and g['version']==k)) for s in ('lancer-v7','old-main','holdout-orbit')],flush=True)
 print(out,vid,flush=True)
if __name__=='__main__':main()
