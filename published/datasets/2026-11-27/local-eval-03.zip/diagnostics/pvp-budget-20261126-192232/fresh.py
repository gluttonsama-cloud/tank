from compare import *
if __name__=='__main__':
 out=Path(__file__).resolve().parent;pool=json.loads((root/'.local/cycle/pvp/opponents.json').read_text())
 vid=json.loads((out/'12ms.json').read_text())['candidate'];rng=random.Random(8316792);tasks=[];labels=[]
 for op in ('router-v2','boss-specialist-v7'):
  for idx in range(6):
   seed,ours,foe=[rng.getrandbits(30) for _ in range(3)]
   for side in (0,1):
    for key,version in [('v2',pool['router-v2']),('12ms',vid)]:
     tasks.append(Trial(op,str(versions.snapshot_data(root,version)),str(versions.snapshot_data(root,pool[op])),(GameCase(seed,side,ours,foe,1),)));labels.append(key)
 with open_pool(4) as ex: results=[dict(version=k,**r) for k,r in zip(labels,ex.map(play,tasks),strict=True)]
 (out/'fresh.json').write_text(json.dumps(results))
 for k in ('v2','12ms'):print(k,[(s,[sum(r['wins'][i] for r in results if r['style']==s and r['version']==k) for i in (0,1)]) for s in ('router-v2','boss-specialist-v7')])
