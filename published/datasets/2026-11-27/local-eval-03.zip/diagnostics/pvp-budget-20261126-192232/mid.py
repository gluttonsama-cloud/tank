from compare import *
if __name__=='__main__':
 out=Path(__file__).resolve().parent
 pool=json.loads((root/'.local/cycle/pvp/opponents.json').read_text())
 base=versions.snapshot_data(root,pool['router-v2']);src=out/'candidate12';shutil.copytree(base,src)
 f=src/'policy_b/boss_local_policy.py';f.write_bytes(f.read_bytes().replace(b'"budget_ms": None',b'"budget_ms": 12'))
 vid=versions.create_from_directory(root,src,'style-switch','天梯实验：切换后每帧瞄准搜索限时 12 毫秒')['id'];folder=versions.snapshot_data(root,vid)
 ref=json.loads((out/'hard-paired.json').read_text());tasks=[]
 for r in ref:
  if r['version']=='v2':
   case={k:r['games'][0][k] for k in GameCase.__dataclass_fields__}
   tasks.append(Trial(r['style'],str(folder),str(versions.snapshot_data(root,pool[r['style']])),(GameCase(**case),)))
 with open_pool(4) as ex: rows=list(ex.map(play,tasks))
 (out/'12ms.json').write_text(json.dumps(dict(candidate=vid,results=rows)))
 print(vid, [(s,[sum(r['wins'][i] for r in rows if r['style']==s) for i in (0,1)]) for s in ('router-v2','boss-specialist-v7')],flush=True)
 ms=[]
 for mid in (25808,27485,27492,27531,27604,27608):
  p=root/'.local/cycle/ladder';d=json.load(gzip.open(p/'replays'/f'{mid}.json.gz'));s=int(json.loads((p/'games'/f'{mid}.json').read_text())['own_side']=='blue')
  for rep in range(3):
   random.seed(mid);b=load_strategy(folder)();info=match_info(generate_map(d['map']['seed']),s,'参赛队伍');del info['map']['seed'];b.on_match_start(info);a=STILL.copy()
   for frame in d['frames']:
    obs=replay_observation(frame,s)|dict(collision=False,last_action=a);t=time.perf_counter();a=action_fields(b.decide(obs));ms.append((time.perf_counter()-t)*1000);assert not parse_action(a)[1]
 print('p99/max',quantiles(ms,n=100)[98],max(ms))
 (out/'12ms-timing.json').write_text(json.dumps(ms))
