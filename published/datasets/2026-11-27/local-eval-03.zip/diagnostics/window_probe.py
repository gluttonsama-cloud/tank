import ctypes, ctypes.wintypes as w, subprocess, time, sys
from pathlib import Path
u = ctypes.windll.user32
callback_type = ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
def windows():
    result = set()
    @callback_type
    def visit(hwnd, lparam):
        if u.IsWindowVisible(hwnd):
            name = ctypes.create_unicode_buffer(120)
            title = ctypes.create_unicode_buffer(300)
            u.GetClassNameW(hwnd,name,120)
            u.GetWindowTextW(hwnd,title,300)
            if name.value in ("CASCADIA_HOSTING_WINDOW_CLASS","ConsoleWindowClass"):
                result.add((hwnd,name.value,title.value))
        return True
    u.EnumWindows(visit,0)
    return result
for flag in (subprocess.DETACHED_PROCESS,subprocess.CREATE_NO_WINDOW):
    before=windows()
    p=subprocess.Popen([str(Path(".venv/Scripts/python.exe").resolve()),"-c","import time;time.sleep(2)"],creationflags=flag|subprocess.CREATE_NEW_PROCESS_GROUP,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    appeared=set()
    while p.poll() is None:
        appeared.update(windows()-before)
        time.sleep(.01)
    print(flag, sorted(appeared),flush=True)
    time.sleep(.5)
