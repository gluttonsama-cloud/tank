import importlib.util
from itertools import product
from math import cos,sin,radians
from seedcup.game import Game, generate_map, rules
from seedcup.game.engine import Shell
from seedcup.game.runner import match_info
from pathlib import Path
paths=[next(Path('.local/versions').glob('v-008134*/files/bot.py')),Path('strategies/lancer/bot.py')]
bots=[]
for index,path in enumerate(paths):
    spec=importlib.util.spec_from_file_location(f'b{index}',path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); bots.append(mod.Lancer)
seed=1200500144
gm=generate_map(seed)
idle={'forward':0,'turn':0,'fire':False}

def compare(side, gap, heading, shot, distance, dy):
    actions=[]
    x,y=13+gap,12+dy
    sh=cos(radians(shot)),sin(radians(shot))
    sx,sy=x-distance*sh[0],y-distance*sh[1]
    tx,ty=16,12
    if side:
        x,sx,tx=32-x,32-sx,32-tx
        heading=180-heading
        sh=(-sh[0],sh[1])
    for bot in bots:
        g=Game(gm); g.tick=750
        me,them=g.tanks[side],g.tanks[1-side]; me.x,me.y,me.h=x,y,heading; them.x,them.y=tx,ty
        if not g._free(x,y,them): return
        g.shells=[Shell(0,1-side,sx,sy,*sh)]
        p=bot(); p.on_match_start(match_info(gm,side,'dummy',game=0)); act=p.decide(g.observe(side)); moves=[idle,idle]; moves[side]=act; g.step(moves)
        actions.append((act,me.zone_damage,me.hp,round(me.x,3),round(me.y,3)))
    return actions
for args in product((.08,.12,.16,.2),(0,30,45,90,120,145,180,210,225,270,300,330),(180,160,145,140,130,120,115,90,70,30,0),(.9,1.3,1.6,2,2.5,3,4),(0,.1,-.1,.2,-.2)):
    a,b=(compare(side,*args) for side in (0,1))
    if a and b and all(v[0][1] and not v[1][1] and v[1][2]==100 for v in (a,b)):
        print(args,a,b); break
