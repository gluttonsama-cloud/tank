import ctypes, ctypes.wintypes as w, subprocess, time, sys
from pathlib import Path
u = ctypes.windll.user32
callback_type = ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
def windows():
    result = set()
    @callback_type
    def visit(hwnd, lparam):
        if u.IsWindowVisible(hwnd):
            name = ctypes.create_unicode_buffer(120)
            title = ctypes.create_unicode_buffer(300)
            u.GetClassNameW(hwnd,name,120)
            u.GetWindowTextW(hwnd,title,300)
            if name.value in ("CASCADIA_HOSTING_WINDOW_CLASS","ConsoleWindowClass"):
                result.add((hwnd,name.value,title.value))
        return True
    u.EnumWindows(visit,0)
    return result
before=windows()
p=subprocess.Popen([sys.executable,"-m","pytest","-q","tests/test_jobs.py","tests/test_screening.py","tests/test_eval_runtime.py"],creationflags=subprocess.CREATE_NO_WINDOW,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
appeared=set()
while p.poll() is None:
    appeared.update(windows()-before)
    time.sleep(.015)
print(p.stdout.read().decode(errors="replace"),"VISIBLE WINDOWS:",appeared,flush=True)
sys.exit(p.returncode or bool(appeared))
